# Research sources captured for the rebuild

## CSI KJSIT public reference

Source: [CSI KJSIT home](https://csi.kjsieit.in/). The public site links to `index.html`, `team.php`, `events.php`, `gallery_event.php`, `technicalSaturday.php`, `alumni.php`, `newsletters.php` and `sponsors.php`. It includes CSI/KJSIT social links and institutional/faculty statements. The home page states CSI KJSIT's chapter was established in 2009 and includes institute recognition and messages from the Principal, Vice Principal, Convener and Coordinators.

- [Team](https://csi.kjsieit.in/team.php): Core 2024–25 and Sub-Core 2024–25 names, roles and public profile/email links; image paths include `images/core_24/` and `images/core_socials/`.
- [Events](https://csi.kjsieit.in/events.php): eight archived events with source descriptions, dates/times and original Google Forms registration URLs; displayed dates have no year, so they are labelled as source listings, not future events.
- [Gallery](https://csi.kjsieit.in/gallery_event.php): eight original photos include `images/c2.JPG`, `images/g11_smol.jpg` through `g15_smol.jpg`, `images/c1.JPG` and `images/c0.JPG`; no captions or event/date metadata were found.
- [Technical Saturdays](https://csi.kjsieit.in/technicalSaturday.php): page provides `All`, `Hardware`, `Software` filters and footer contacts but no session titles/details; no missing events were invented.
- [Alumni](https://csi.kjsieit.in/alumni.php): six displayed testimonials by Fenil Desai, Pranav Bhatt, Jigar Thakkar, Sanchay Vyas, Rahul Deshpande and Karan Bhavsar.
- [Newsletters](https://csi.kjsieit.in/newsletters.php): visible status is “Coming Soon!”; no issue titles or files are shown. The live countdown is dynamic/stale and is not copied.
- [Sponsors](https://csi.kjsieit.in/sponsors.php): archive has year controls for 2023/2022/2021, sponsor names and original logos; some original link destinations are `#`/modal fragments and are not presented as partner websites.

A dedicated eight-page audit also verified the 2024–25 team and sub-core rosters, source Events dates/times, all eight original Google Forms links, the six alumni roles/tenures, sponsor year names, institutional statements and current contact links. The full-page data snapshot is in `client/src/data/reference-page-extracts.json`; code uses structured data in `client/src/data/siteContent.ts`.

The asset map is `client/src/data/sourceAssets.json`. Of 165 source-image records, 163 optimized local image files were retained under `client/public/csi-assets/`; two source image responses were incomplete/unusable, and relevant UI falls back without breaking. Optimization kept the mapped files at about 10.5 MB; the raw 143 MB download directory and temporary source manifest were removed from the website bundle. (The separate generated video and accurate character-reference JPEGs add about 5.2 MB.)

## Candidate licensed character references and viewer control

- [Optimus Prime transform animation model](https://sketchfab.com/3d-models/bumblebee-optimus-prime-transform-animation-35f9cb09b1b248c7bd6b12912ac8cd3a) by DIO (`dioiiiii2`): public model metadata reports `animationCount: 1`, downloadable, CC BY 4.0. The unauthenticated download endpoint returned HTTP 401, so the site uses the public viewer and links the creator/license. The viewer animation still needs end-to-end verification in the running site.
- [Bumblebee Revenge of the Fallen model](https://sketchfab.com/3d-models/transformers-revenge-of-the-fallen-bumblebee-b9e6ae71a8c2463c86ffbc53fcca4b34) and [Autobot Bumblebee model](https://sketchfab.com/3d-models/autobot-bumblebee-c69498aa17254e74a0639d0a1ba575aa), both by Pipogame: metadata reports zero animation tracks; both pages list CC BY 4.0. They are reference artwork only, not transforming assets.
- [Sketchfab Viewer API initialization](https://sketchfab.com/developers/viewer/initialization) and [Viewer API functions](https://sketchfab.com/developers/viewer/functions) document `getAnimations`, `setCurrentAnimationByUID`, `seekTo(seconds)`, `pause` and `setSpeed` for scroll-scrubbing a public viewer.

The Bumblebee video is a generated, silent rendered visual prototype, not a rigged model. Its player remains muted and only seeks to frames in response to normal scroll. The accurate vehicle-mode model thumbnail is explicitly shown as a static fallback; attribution is displayed in the site footer/scene. The two character MP3s are intentionally absent until the user supplies them.
