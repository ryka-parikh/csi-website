import sourceAssetsJson from "./sourceAssets.json";

type SourceAsset = {
  url: string;
  path?: string;
  sourcePath?: string;
  pages?: string[];
};

export const sourceAssets = sourceAssetsJson as SourceAsset[];

export function mediaBySourcePath(suffix: string): string {
  const normalized = suffix.toLowerCase().replace(/^\/+/, "");
  return (
    sourceAssets.find((asset) => asset.sourcePath?.toLowerCase().endsWith(normalized))?.path ??
    ""
  );
}

export function mediaForPage(page: string): SourceAsset[] {
  return sourceAssets.filter((asset) => asset.pages?.includes(page) && Boolean(asset.path));
}

export function mediaForPageExcluding(page: string, excludedFragments: string[] = []): SourceAsset[] {
  return mediaForPage(page).filter((asset) =>
    !excludedFragments.some((fragment) => asset.sourcePath?.toLowerCase().includes(fragment.toLowerCase())),
  );
}
