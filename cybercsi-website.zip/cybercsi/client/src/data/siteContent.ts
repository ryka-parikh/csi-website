export type SocialLink = { label: string; href: string };

export const siteNav = [
  { label: "Home", href: "/", icon: "home" },
  { label: "Events", href: "/events", icon: "events" },
  { label: "Team", href: "/team", icon: "team" },
  { label: "Gallery", href: "/gallery", icon: "gallery" },
  { label: "Technical Saturdays", href: "/technical-saturdays", icon: "technical" },
  { label: "Alumni", href: "/alumni", icon: "alumni" },
  { label: "Newsletters", href: "/newsletters", icon: "newsletter" },
  { label: "Sponsors", href: "/sponsors", icon: "sponsors" },
] as const;

export const socialLinks: SocialLink[] = [
  { label: "Facebook", href: "https://www.facebook.com/kjsieit" },
  { label: "Instagram", href: "https://www.instagram.com/csi_kjsieit/?hl=en" },
  { label: "LinkedIn", href: "https://www.linkedin.com/company/csi-kjsieit-student-s-chapter/" },
  { label: "YouTube", href: "https://www.youtube.com/channel/UCjCxhLRs5xExG4KW3TdlxKg" },
  { label: "College website", href: "https://kjsieit.somaiya.edu/en" },
];

export const homeContent = {
  institute: {
    title: "About K. J. Somaiya Institute of Technology",
    location: "Sion, Mumbai",
    summary:
      "KJSIT has been accredited by NAAC with 'A' grade (3.21 CGPA) for 5 years. Three programs of KJSIT have been accredited by the National Board of Accreditation (NBA). KJSIT has been presented the Best College Award by the University of Mumbai for A.Y. 2018–19 (Urban Region), CSI (Mumbai Chapter) and ISTE (MH and Goa Section).",
    detail:
      "The institute aims to provide the necessary dynamism in the light of ever-expanding knowledge and changing socio-economic requirements of modern society. Since its inception, the institute has been striving to develop itself into an institute of quality and excellence in technical education, in consonance with contemporary and future needs and a fine blend of traditional values and modern education.",
  },
  origin: {
    title: "How was CSI founded?",
    year: "2009",
    body:
      "The Computer Society of India is the first and largest body of computer professionals in India. It was started on 6 March 1965 by a few computer professionals and has grown to be a national body representing them. Having 72 chapters across India, 511 student branches and 100,000 members, it is a non-profit professional meet to exchange views and information, learn and share ideas. K. J. Somaiya Institute of Engineering and I.T. (KJSIT)'s CSI Students' Chapter was established in 2009. The KJSIT CSI committee is selected from its student members every year. Under the guidance of faculty advisors, the committee works on various activities, chiefly organising the technical festival Renaissance. In addition, it conducts workshops and seminars based on industry trends, non-technical events, workshops and interactions with industry members. Above all, it believes in working together as a team for the overall development of its members.",
  },
  aboutCsi: {
    title: "About CSI",
    body:
      "Computer Society of India, KJSIT Chapter organizes many workshops, seminars and other technical and non-technical events every year for students. Students work diligently day and night, developing skills like team spirit and leadership. KJSIT has received the Best College Award from CSI, Mumbai Chapter. Professor and mentor Mr. Uday Rote received the Best HoD Award by CSI in 2018. CSI, KJSIT is not a team but a family, and we will always remember the time we spent together.",
  },
  statements: [
    {
      group: "Words from Principal and Vice Principal",
      name: "Dr. Suresh Ukarande",
      role: "Principal, KJSIT",
      image: "images/duh/ukku.jpg",
      quote:
        "K. J. Somaiya Institute of Engineering and Information Technology (KJSIT) provides quality education to engineering students. We motivate, facilitate and guide our students by providing lifelong learning opportunities in a conducive learning environment. The role of engineers in shaping the modern world is incredible. Hence the ultimate aim of any distinguished technical education institute should be to promote a multifaceted development of students.",
    },
    {
      group: "Words from Principal and Vice Principal",
      name: "Dr. Sunita Patil",
      role: "Vice Principal, KJSIT",
      image: "images/duh/saritaMam.jpg",
      quote:
        "The Institute is not only looking at the academic growth of the students but also trying its best for all-round professional and social development through various professional international and national bodies such as IEEE, IETE, CSI, IET, ISTE and IEI. K. J. Somaiya Institute of Engineering and Information Technology is attaining great heights under the auspices of our Somaiya Trust Chairman, Hon. Shri Samir Somaiya, guidance of Secretary, Hon. Lt. Gen Jagbir Singh, Provost Hon. Prof. V. N. Rajasekharan Pillai and Principal, Dr. Suresh K. Ukarande.",
    },
    {
      group: "Words from CSI KJSIT Convener",
      name: "Prof. Uday Rote",
      role: "CSI Convener",
      image: "images/alumni/roteSir.JPG",
      quote:
        "CSI-KJSIT is a platform which helps students in their holistic development by implementing proactive learning solutions. It helps students develop a creative mindset and instills in them the zeal to never stop learning and never give up. Our college is awarded the Best College Award by CSI, Mumbai Chapter. It was possible only because of the continuous efforts of the students and immense support of Principal Dr. Suresh Ukarande and other faculty members.",
    },
    {
      group: "Words from CSI KJSIT Coordinators",
      name: "Prof. Nisha Vanjari",
      role: "CSI Coordinator",
      image: "images/alumni/nishaMam.jpg",
      quote:
        "I learn and explore with experiences in Computer Science due to the creative nature of programming and technology. As programming plays a vital role in every field, CSI initiates education and provides a platform for students and institutes. As a CSI member I am blessed with the opportunity to discover and experience technology with my students.",
    },
    {
      group: "Words from CSI KJSIT Coordinators",
      name: "Dr. Mansing Rathod",
      role: "CSI Coordinator",
      image: "images/alumni/MansingRathodSir.jpg",
      quote:
        "The Computer Society of India (CSI)-KJSIT is a non-profit professional meet to exchange views and information, to learn and share ideas, and to encourage students. It helps students develop a creative mindset and innovative thinking, with a passion to never stop learning and give up. Our college is awarded the Best College Award by CSI, Mumbai Chapter. Principal Dr. Suresh Ukarande and other faculty members, together with students, have taken continuous efforts for the award.",
    },
  ],
  legacyContacts: [
    { name: "Manav Gupta", role: "Chairperson", phone: "+91 76200 39068", email: "manav.gupta@somaiya.edu" },
    { name: "Jeet Poladia", role: "Vice Chairperson", phone: "+91 98191 87532", email: "jeet.poladia@somaiya.edu" },
    { name: "Pruthviraj Patil", role: "Secretary", phone: "+91 7620172617", email: "pruthviraj.p@somaiya.edu" },
  ],
};

export const coreTeam = [
  { role: "Chairperson", name: "Aryan Solanki", image: "images/pfp.png", email: "solanki.ap@somaiya.edu", socials: ["https://www.linkedin.com/in/aryan-solanki-a1b703283?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=ios_app", "https://www.instagram.com/aryyansolanki/profilecard/?igsh=Y2ZyODVtazM3bmRp", "https://x.com/aryyansolanki?s=21&t=FhtYY3If7pKha4OD5H8Z6g"] },
  { role: "Vice Chairperson", name: "Ojas Narsana", image: "images/pfp.png", email: "ojas.n@somaiya.edu", socials: [] },
  { role: "Secretary", name: "Navang Shah", image: "images/core_24/sec.png", email: "navang.shah@somaiya.edu", socials: ["https://in.linkedin.com/in/navang-shah-43b327204", "https://www.instagram.com/the_navang/", "https://x.com/Navangs23"] },
  { role: "Chief Executive Officer", name: "Daksh Tanna", image: "images/pfp.png", email: "daksh.tanna@somaiya.edu", socials: ["https://www.linkedin.com/in/daksh-t-271588201/", "https://www.instagram.com/daksh_tanna/"] },
  { role: "Financial Secretary", name: "Soham Raut", image: "images/core_24/financial_sec.jpg", email: "soham.mr@somaiya.edu", socials: ["https://www.linkedin.com/in/soham-m-raut", "https://www.instagram.com/im_soham_raut_/", "https://x.com/SohamMRaut2310"] },
  { role: "Public Relations Officer", name: "Shivam Gupta", image: "images/pfp.png", email: "shivam13@somaiya.edu", socials: ["https://www.linkedin.com/in/shivam-gupta-02b240285/", "https://www.instagram.com/_shivxm.13/profilecard/?igsh=MXViYjR0YThrbjBzaw=="] },
  { role: "Chief Technical Officer", name: "Hrishin Bhamre", image: "images/core_24/cto.png", email: "hrishin.bhamre@somaiya.edu", socials: ["https://www.linkedin.com/in/hrishin-bhamre/", "https://www.instagram.com/hrishinn/", "https://x.com/hrishinn"] },
  { role: "Chief Marketing Officer", name: "Smit Karelia", image: "images/pfp.png", email: "", socials: [] },
];

export const subCoreTeam = [
  { role: "Joint Secretary", name: "Sanskar Srivastava", image: "images/core_24/jt_sec.png" },
  { role: "Joint Chief Executive Officer", name: "Amey Dabhole", image: "images/core_24/jt_ceo.png" },
  { role: "Organizing Admin", name: "Yash Bid", image: "images/core_24/org_admin1.png" },
  { role: "Organizing Admin", name: "Prem Panchal", image: "images/core_24/org_admin2.png" },
  { role: "Technical Admin", name: "Yash Ranbhare", image: "images/core_24/tech_admin1.png" },
  { role: "Technical Admin", name: "Shubham Darji", image: "images/core_24/tech_admin2.png" },
  { role: "Joint Technical Admin", name: "Yohan Gala", image: "images/core_24/jt_tech_admin.png" },
  { role: "DCC Admin", name: "Ritika Jain", image: "images/core_24/dcc_admin.png" },
  { role: "Publicity Admin", name: "Khadija Manasawala", image: "images/core_24/pr_admin1.png" },
  { role: "Jt. Publicity Admin", name: "Vrunda Parekh", image: "images/core_24/jt_pr_admin.png" },
  { role: "Jt Organizing Admin", name: "Pradnyesh Kamble", image: "images/core_24/jt_org_admin.png" },
  { role: "Jt Organizing Admin", name: "Rohit Patil", image: "images/core_24/jt_org_admin2.png" },
  { role: "Marketing Admin", name: "Abhishek Pandey", image: "images/core_24/marketing_admin1.png" },
  { role: "Jt Marketing Admin", name: "Krisha Shethia", image: "images/core_24/marketing_admin2.png" },
];

export const teamGroups = ["Technical Team", "Marketing Team", "Publicity Team", "Organizing Team", "Digital Cinematography Team"];

export const teamContacts = [
  { name: "Aryan Solanki", role: "Chairperson", phone: "+91 98218 24064", email: "solanki.ap@somaiya.edu" },
  { name: "Ojas Narsana", role: "Vice Chairperson", phone: "+91 98191 47148", email: "ojas.n@somaiya.edu" },
  { name: "Navang Shah", role: "Secretary", phone: "+91 98337 91921", email: "navang.shah@somaiya.edu" },
];

export const events = [
  { title: "Capture the Flag", description: "Join us for an exciting Capture the Flag event! Teams compete to capture the main flag. Strategy, teamwork and quick thinking are essential as players navigate the field, dodge opponents and work together to secure victory. Bring your competitive spirit for an action-packed adventure!", date: "14th & 15th October", time: "Full Time", register: "https://forms.gle/7CYYNMrE6SfbQmeGA" },
  { title: "Code Compile Run", description: "Prepare for mind-bending challenges and strategic showdowns in a larger-than-life version of this beloved event. Think beyond the usual norms of programming: expect surprises, strategy and a dash of unpredictability.", date: "14th October", time: "12:00pm – 1:30pm", register: "https://forms.gle/GXAtqtoSt2jyudcp6" },
  { title: "Game Storm Arena", description: "Join fellow gamers in an electrifying atmosphere where consoles unite through shared passions. Whether a seasoned pro or casual player, this is a chance to level up the gaming experience.", date: "14th & 15th October", time: "Full Time", register: "https://forms.gle/RCkZXgrpzRDpXeKk7" },
  { title: "Murder Mystery", description: "A whodunit-style game where players assume roles of detectives, suspects or victims. Uncover the culprit behind a fictional crime by gathering clues, questioning suspects and solving puzzles together. The game blends deduction, strategy and storytelling for an immersive experience.", date: "15th October", time: "10am – 12pm", register: "https://forms.gle/yk7GKvdcoyeSda217" },
  { title: "Sacred Games", description: "From athletic showdowns to creative quests, teamwork, speed and strategy are tested through a series of exciting rounds. Rally your squad, gather your wits and prepare for unexpected twists. Only the sharpest and most dynamic teams make it to the final round.", date: "15th October", time: "2:30pm – 5:30pm", register: "https://forms.gle/saNf64sXA93D4xH96" },
  { title: "Technical Housie", description: "Push problem-solving skills to the limit with a game like no other. CSI Technical Housie challenges your mind with an exciting twist on the classic game: it is not just about numbers, but strategy, technical prowess and quick thinking.", date: "15th October", time: "12pm – 2pm", register: "https://forms.gle/nc92hVjC4Ro1Dn6WA" },
  { title: "Treasure Hunt", description: "Designed to be fun and challenging for all participants, regardless of fitness level or experience. Each team works together; communication and collaboration are key to success.", date: "14th October", time: "3pm – 5:30pm", register: "https://forms.gle/DoEoD2JpCr4EttSSA" },
  { title: "Byte Sprint Relay", description: "A tech-themed relay race where teams tackle a coding puzzle before handing off the baton. A game where tech meets fun in an action-packed team showdown, with surprise tasks, clever strategies and a race against the clock.", date: "14th October", time: "1:30pm – 3:00pm", register: "https://forms.gle/BGSdBKh1ZB4fPhKDA" },
];

export const alumniStories = [
  { name: "Fenil Desai", role: "CSI CP-2019-20", quote: "I have been an active part of CSI since the very beginning of my journey at KJSIEIT. I was the Joint Head of the Organising team initially and then went on to become the Joint Secretary and then the Chairperson in the 2019-20 tenure. Throughout these three years working for CSI, I enhanced my organising and people skills while also being involved in various technical activities right from organising them to inculcating knowledge from them. Being someone from a Computer Engineering background, CSI was an excellent platform for me as it provided enough knowledge and confidence to step into the outside world without fear. CSI is not a committee which only organises seminars, workshops and events related to the software side, but also exposes you to the hardware side of the industry, something I am really proud of as part of its legacy. CSI has played an instrumental role in shaping my career goals and has helped me figure out my plans for the future after my undergraduate degree. I believe each and every student of KJSIEIT must participate in a committee, student body or club to get a full college experience and nurture their personality holistically. Being involved with it for such a long time, I assure you that CSI is one of the best platforms at KJSIEIT to do so." },
  { name: "Pranav Bhatt", role: "CSI VCP 2019-20", quote: "I began my journey with CSI as a CSI publicity team member and there was so much that I could learn right from the first year of me joining CSI. Being a part of this team made it easy to get to know my seniors and batchmates and interact with more people. Throughout the tenure, working with my team members and seniors was a sheer joy and made learning new things so much fun. The best thing about CSI is that every member is a part of the CSI family, and it makes working together so much more exciting. Working hard in CSI was rewarding; it not only imparted enhanced technical skills but also taught me to be a better leader and a better human being. The team members were always ready to work and help each other, and that's the essence of being the best technical committee from my perspective. TEAMWORK." },
  { name: "Jigar Thakkar", role: "CSI CP 2018-19", quote: "I joined CSI in my second year at the college. It was a great learning experience to hold various positions of responsibility during three tenures. I joined CSI as an Organizing team member, then became the Organizing Head and then went on to become the Chairperson for the 2018-19 tenure. These three years immensely helped me enhance my ability to work with a team, manage multiple tasks at a time and develop leadership. Organizing seminars, workshops, guest lectures and the technical festival Renaissance during my three-year journey at CSI helped shape my career and provided amazing memories to cherish for a lifetime. It strengthened my people, managerial and technical skills. Since I was an active member of CSI, I can surely assure that it is one of the best committees to work with." },
  { name: "Sanchay Vyas", role: "CSI VCP 2018-19", quote: "CSI will always hold a special place in my heart. It was the first committee which I joined in my college. CSI changed my perception of college and brought about a change where I can decide how I want my college life to be. It has been a great learning experience and has taught me to blend technological learning with managerial skills. From organising guest lectures, bringing in foreign college delegates and holding workshops, to the technical festival of the college, it has been a rollercoaster ride with ups and downs. I joined CSI as an Organising team member and went on to become the Joint Operating Officer and then the Vice Chairperson in 2018-19. These three years were a pinnacle in shaping my career and helping me figure out what I wanted to pursue after my undergraduate degree. Being an active member, I can assure you that CSI plays an important role in nurturing the future of students." },
  { name: "Rahul Deshpande", role: "CSI CP 2017-18", quote: "My journey with CSI began within the second week of my engineering life. A workshop on application development made me realise that I wanted to become a part of the CSI family. A journey from enthusiastic workshop attendee to Organising Admin and then finally Chairperson was filled with learnings and memories that I will always cherish. Providing value to students, team spirit and personal growth have always been the core of CSI's culture. The joy of working with different people, organising workshops and seminars, managing teams, solving technical issues, handling sponsors, negotiating with vendors, having discussions with other committee members and engaging with students from different colleges has been a heck of a ride. CSI taught me to stand up for what is right, embrace failures, develop a problem-solving attitude and make lifelong friendships. I am proud of the professional character CSI helped me develop, and grateful for the platform to develop my technical skills and prepare to become a leader." },
  { name: "Karan Bhavsar", role: "CSI VCP 2017-18", quote: "I joined KJSIEIT like any other student, dreaming of becoming an IT or computer engineer, but little did I know what engineering technically or practically meant until I was introduced to CSI. A workshop on Android, conducted by CSI, made me fall for hands-on experiences and I eventually joined the team to learn more. Being in CSI, I gained skills I wondered if I could ever possess. From learning about a workshop to actually organising it, the experience helped me and other team members. It was only when being on the ground and leading teams to pull off the best technical festival and events that I experienced the skills to build my career and life confidently. Learning and growing, managing time with academics and exams, and interacting with faculty made me grateful for my tenure as VCP of this committee, working with the best team '18 and ending with plentiful memories." },
];

export const sponsorsByYear: Record<string, string[]> = {
  "2023": [
    "Sundaram", "Bell", "Bookchor", "The Sensei's Store", "Smash", "Simply Gaming", "Hover Robotix", "Rare Escape Mumbai", "Alpha 8", "Mojoco", "Console", "Rogue Code", "Campus Times Pune", "What The Fries", "Mobilla", "Sachi Shiksha", "Bombay Optical", "RevUp", "TechBrain", "Off Kicks Inc.", "Dev Textiles", "LWT Academy", "NoEscape", "X Boom", "Languify", "Sach Kahoon Punjabi", "EazyDiner", "Eyeconic", "MENTORx", "Vedant", "Mumbai Messy Miracles", "GetMyFest"
  ],
  "2022": [
    "Asus", "Smokey Dough", "Bounce Inc", "Gifteeng", "Campus Times Pune", "The Education Tree", "Bell Mobile Accessories", "3P Consulting Engineers LLP", "ReadOn", "Ensemble", "Book Chor", "S & M Eyewear", "COCO Sports", "SI-UK", "EazyDiner", "TechBairn", "Art Awesomeness", "MyStudia App", "Digifuse", "Axplorar Holidays", "Card Isle", "Amul", "1 Password", "Seed Global Education", "Upcoming Engineer", "ischool connect", "Bare Bone", "Jawed Habib Salon", "elearnmarkets", "Second Tongue", "No Escape", "Hoodzilla", "Mad About Sports", "Legit Energy Drink", "Aspire MBA", "Delta Store", "Rogue Code", "Open Canvas", "Conifer Greens", "Smaaash", "Imperial Overseas", "NTR Shah", "Sundaram Multi Pap Ltd.", "The Phonetic Store", "Digimate"
  ],
  "2021": [
    "ICICI Direct", "Be the Mard", "Brew House Tea", "Charcoal Eats", "Cinnamon Sticks", "Craft Tree Creations", "Delta Store", "Digimate", "Du Assassins", "Eat Sure", "Elan Accessories", "Enlighten India", "Ensemble", "Finladder", "Foodwalas", "Fuschia Vkare", "Ink House Tattoos", "MacV", "The Money Roller", "SI-UK", "Sybgen", "Upcoming Engineer", "Urbane Salon", "Voluptuous Vibe"
  ],
};

export const sponsorWebsiteLinks: Record<string, string> = {
  "Asus": "https://linktr.ee/Asus_India",
  "Smokey Dough": "https://www.smokeydough.in/",
  "Bounce Inc": "https://linktr.ee/bounceincindia",
  "Gifteeng": "https://www.gifteeng.com/",
  "Campus Times Pune": "https://www.campustimespune.com/",
  "Bell Mobile Accessories": "https://www.amazon.in/stores/page/B0D9F651-DBEE-402D-8429-38520E92AC7D?ingress=3",
  "S & M Eyewear": "https://samandmarshalleyewear.in/",
  "COCO Sports": "https://www.mycocosports.com/pages/techtober-sale",
  "SI-UK": "https://linktr.ee/siukindia/",
  "EazyDiner": "https://www.eazydiner.com/mumbai",
  "TechBairn": "https://linktr.ee/techbairn",
  "MyStudia App": "https://linktr.ee/mystudia/",
  "Axplorar Holidays": "https://axplorar.com/",
  "Amul": "https://amul.com/",
  "1 Password": "https://1password.com/",
  "Seed Global Education": "https://linktr.ee/seedglobaleducation",
  "ischool connect": "https://linktr.ee/ischoolconnect/",
  "elearnmarkets": "https://www.elearnmarkets.com/",
  "Hoodzilla": "https://www.hoodzilla.in/",
  "Mad About Sports": "https://linktr.ee/madaboutsports",
  "Legit Energy Drink": "https://www.lotusventures.in/lotus-beverages",
  "Delta Store": "https://linktr.ee/Delta__Store",
  "Open Canvas": "https://linktr.ee/opencanvas",
  "Conifer Greens": "https://conifergreens.com/",
  "Smaaash": "https://linktr.ee/smaaashentertainment/",
  "Imperial Overseas": "https://www.imperial-overseas.com/",
  "Sundaram Multi Pap Ltd.": "https://sundaramstore.com/",
  "Elan Accessories": "https://www.elanaccessories.in/",
  "Finladder": "https://efinladder.com/",
  "Foodwalas": "https://www.foodwalas.com/",
  "Fuschia Vkare": "https://www.myfuschia.com/",
  "Upcoming Engineer": "https://www.upcomingengineer.com/",
  "Urbane Salon": "https://thedigitalbusinesscards.com/urbane-salon/",
};

export const technicalSaturday = {
  title: "Technical Saturday",
  filters: ["All", "Hardware", "Software"],
  note: "The public reference presents All, Hardware and Software filters, but its accessible page text does not expose individual session titles or descriptions.",
};

export const newsletters = {
  title: "CSI - KJSIEIT Newsletters",
  status: "Coming Soon!",
};

export const sketchfabAttribution = {
  title: "Bumblebee - Optimus Prime Transform Animation",
  author: "DIO",
  href: "https://sketchfab.com/3d-models/bumblebee-optimus-prime-transform-animation-35f9cb09b1b248c7bd6b12912ac8cd3a",
  license: "CC BY 4.0",
  licenseHref: "https://creativecommons.org/licenses/by/4.0/",
};

export const bumblebeeAttribution = {
  title: "Transformers Revenge of the Fallen Bumblebee",
  author: "Pipogame",
  href: "https://sketchfab.com/3d-models/transformers-revenge-of-the-fallen-bumblebee-b9e6ae71a8c2463c86ffbc53fcca4b34",
  license: "CC BY 4.0",
  licenseHref: "https://creativecommons.org/licenses/by/4.0/",
};
