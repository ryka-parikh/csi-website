import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { usePreferences } from "@/contexts/PreferencesContext";
import { sketchfabAttribution } from "@/data/siteContent";
import AudioControl from "@/components/AudioControl";
import MechanicalIcon from "@/components/MechanicalIcon";

type AnimationTrack = [string, string, number];
type ViewerApi = {
  start: () => void;
  pause: (callback?: (error: unknown) => void) => void;
  seekTo: (seconds: number, callback?: (error: unknown) => void) => void;
  getAnimations: (callback: (error: unknown, animations: AnimationTrack[]) => void) => void;
  setCurrentAnimationByUID: (uid: string, callback?: (error: unknown) => void) => void;
  setCycleMode?: (mode: "one", callback?: (error: unknown) => void) => void;
  addEventListener: (event: string, callback: (value?: unknown) => void) => void;
  removeEventListener?: (event: string, callback: (value?: unknown) => void) => void;
};
type ViewerClient = { init: (uid: string, options: Record<string, unknown>) => void };
declare global { interface Window { Sketchfab?: new (version: string, iframe: HTMLIFrameElement) => ViewerClient } }

const MODEL_UID = "35f9cb09b1b248c7bd6b12912ac8cd3a";
const VIEWER_SCRIPT = "https://static.sketchfab.com/api/sketchfab-viewer-1.12.1.js";
let viewerScriptPromise: Promise<void> | null = null;
function loadViewerScript() {
  if (window.Sketchfab) return Promise.resolve();
  if (viewerScriptPromise) return viewerScriptPromise;
  viewerScriptPromise = new Promise<void>((resolve, reject) => {
    const script = document.createElement("script"); script.src = VIEWER_SCRIPT; script.async = true;
    script.onload = () => resolve(); script.onerror = () => reject(new Error("3D viewer script unavailable")); document.head.appendChild(script);
  });
  return viewerScriptPromise;
}
gsap.registerPlugin(ScrollTrigger);

export default function OptimusScene() {
  const rootRef = useRef<HTMLElement>(null); const frameRef = useRef<HTMLIFrameElement>(null); const apiRef = useRef<ViewerApi | null>(null); const durationRef = useRef(0);
  const [ready, setReady] = useState(false); const [failed, setFailed] = useState(false); const [progress, setProgress] = useState(0); const [duration, setDuration] = useState(0);
  const { preferences } = usePreferences(); const poster = "/csi-assets/optimus-reference.jpg";

  useEffect(() => {
    const root = rootRef.current; const iframe = frameRef.current;
    if (!root || !iframe || preferences.reducedMotion || preferences.simplified3d) return;
    let disposed = false; let observer: IntersectionObserver | null = null; let timeout = 0;
    const fail = () => { window.clearTimeout(timeout); if (!disposed) setFailed(true); };
    const initialize = async () => {
      timeout = window.setTimeout(fail, 15000);
      try {
        await loadViewerScript();
        if (disposed || !window.Sketchfab) return;
        const client = new window.Sketchfab("1.12.1", iframe);
        client.init(MODEL_UID, {
          autostart: 0, autospin: 0, transparent: 1, ui_controls: 0, ui_infos: 0, ui_general_controls: 0, ui_stop: 0,
          success: (api: ViewerApi) => {
            apiRef.current = api; api.start();
            api.addEventListener("viewerready", () => {
              if (disposed) return;
              api.getAnimations((error, animations) => {
                if (disposed) return;
                if (error || !animations?.length) { fail(); return; }
                const track = animations[0]; const trackDuration = Number(track[2]) || 0;
                if (!track?.[0] || !trackDuration) { fail(); return; }
                api.setCurrentAnimationByUID(track[0], (animationError) => {
                  if (disposed) return;
                  if (animationError) { fail(); return; }
                  api.setCycleMode?.("one"); api.pause(); api.seekTo(0);
                  durationRef.current = trackDuration; setDuration(trackDuration); window.clearTimeout(timeout); setReady(true);
                });
              });
            });
          },
          error: () => fail(),
        });
      } catch { fail(); }
    };
    if (!("IntersectionObserver" in window)) void initialize();
    else { observer = new IntersectionObserver((entries) => { if (entries.some((entry) => entry.isIntersecting)) { observer?.disconnect(); void initialize(); } }, { rootMargin: "240px 0px" }); observer.observe(root); }
    return () => { disposed = true; window.clearTimeout(timeout); observer?.disconnect(); apiRef.current?.pause(); apiRef.current = null; };
  }, [preferences.reducedMotion, preferences.simplified3d]);

  useEffect(() => {
    const root = rootRef.current; if (!root || !ready || preferences.reducedMotion || preferences.simplified3d) return;
    const trigger = ScrollTrigger.create({ trigger: root, start: "top top", end: "bottom bottom", onUpdate: (self) => {
      const p = self.progress; setProgress(p);
      if (apiRef.current && durationRef.current > 0) { apiRef.current.pause(); apiRef.current.seekTo(Math.max(0, Math.min(durationRef.current - 0.02, durationRef.current * p))); }
    } });
    return () => trigger.kill();
  }, [ready, preferences.reducedMotion, preferences.simplified3d]);

  const staticMode = preferences.reducedMotion || preferences.simplified3d;
  return (
    <section ref={rootRef} className={`transform-scene transform-scene--optimus ${staticMode ? "is-static" : ""}`} aria-label="Optimus Prime hosted model animation synchronized to page scroll" style={{ "--scene-progress": progress } as React.CSSProperties}>
      <div className="scene-sticky">
        <div className="scene-grid" aria-hidden="true" />
        <div className="scene-copy scene-copy--left"><span className="eyebrow"><i /> OPTIMUS PRIME // TRANSFORMATION</span><h2>ROLL OUT<span>.</span></h2><p>Scroll to scrub the hosted model’s licensed animation track. Move either direction to rewind or continue.</p><AudioControl label="Optimus Prime" fileName="my-name-is-optimus-prime.mp3" available={true} stopWhenOutOfView /></div>
        <div className="scene-stage"><div className="scene-horizon" aria-hidden="true"><span /><span /><span /></div>
          {!staticMode && !failed && !ready && <div className="scene-loading"><span className="loading-dots"><i /><i /><i /></span><small>INITIALIZING MODEL LINK...</small></div>}
          {(failed || staticMode) && <img className="scene-poster" src={poster} alt="Optimus Prime vehicle model reference, shown as a static fallback" />}
          <iframe ref={frameRef} className={`sketchfab-frame ${failed || staticMode ? "is-hidden" : ""}`} title="Optimus Prime vehicle-to-robot animation model by DIO, licensed under CC BY 4.0" allow="autoplay; fullscreen; xr-spatial-tracking" allowFullScreen loading="lazy" />
          <div className="scene-stage-overlay" aria-hidden="true"><span>MODEL LINK // {staticMode ? "STATIC VIEW" : failed ? "UNAVAILABLE" : ready ? "ACTIVE" : "STANDBY"}</span><span>TRACK {duration ? `${duration.toFixed(1)} SEC` : "—"}</span></div>
          {staticMode && <div className="scene-fallback-note">STATIC VIEW // ANIMATION PAUSED BY YOUR DISPLAY PREFERENCE</div>}
          {failed && <div className="scene-fallback-note">MODEL VIEW UNAVAILABLE // STATIC PREVIEW</div>}
        </div>
        <div className="scene-copy scene-copy--right"><span className="scene-readout">{String(Math.round(progress * 100)).padStart(3, "0")}%</span><div className="scene-readout-caption">TRANSFORMATION<br />SEQUENCE</div><div className="scene-progress"><span style={{ transform: `scaleY(${Math.max(progress, 0.02)})` }} /></div><MechanicalIcon name="scroll" size={22} /></div>
        <div className="scene-bottomline"><span>SCROLL TO SCRUB THE MODEL <MechanicalIcon name="scroll" size={14} /></span><span className="scene-attribution"><a href={sketchfabAttribution.href} target="_blank" rel="noreferrer">{sketchfabAttribution.title} · {sketchfabAttribution.author}</a> // {sketchfabAttribution.license} <a href={sketchfabAttribution.licenseHref} target="_blank" rel="noreferrer">(license)</a></span></div>
      </div>
    </section>
  );
}
