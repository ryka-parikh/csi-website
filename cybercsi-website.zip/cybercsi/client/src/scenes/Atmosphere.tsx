import { useEffect, useRef } from "react";
import * as THREE from "three";
import { usePreferences } from "@/contexts/PreferencesContext";

export default function Atmosphere() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { preferences } = usePreferences();
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || preferences.reducedMotion || preferences.simplified3d || !preferences.cinematicEffects) return;
    let renderer: THREE.WebGLRenderer;
    try { renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: false, powerPreference: "low-power" }); }
    catch { canvas.dataset.webgl = "unavailable"; return; }
    const scene = new THREE.Scene(); const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 80); camera.position.set(0, 0, 17);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.45)); renderer.setClearColor(0x080b10, 0);
    let pointsGeometry: THREE.BufferGeometry | null = null; let points: THREE.Points<THREE.BufferGeometry, THREE.PointsMaterial> | null = null;
    if (preferences.particles) {
      const vertices: number[] = [];
      const seed = (index: number, shift: number) => { const value = Math.sin(index * 12.9898 + shift * 78.233) * 43758.5453; return value - Math.floor(value); };
      for (let i = 0; i < 170; i++) vertices.push((seed(i, 1) - 0.5) * 29, (seed(i, 2) - 0.5) * 17, (seed(i, 3) - 0.5) * 16);
      pointsGeometry = new THREE.BufferGeometry(); pointsGeometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
      points = new THREE.Points(pointsGeometry, new THREE.PointsMaterial({ color: 0x4dbbff, size: 0.055, transparent: true, opacity: 0.55, sizeAttenuation: true })); scene.add(points);
    }
    const ring = new THREE.Mesh(new THREE.TorusGeometry(4.6, 0.012, 2, 128), new THREE.MeshBasicMaterial({ color: 0x2588ff, transparent: true, opacity: 0.25, wireframe: true }));
    ring.rotation.x = Math.PI * 0.42; ring.rotation.y = Math.PI * 0.08; scene.add(ring);
    const innerRing = new THREE.Mesh(new THREE.TorusGeometry(3.55, 0.008, 2, 112), new THREE.MeshBasicMaterial({ color: 0x37bfff, transparent: true, opacity: 0.12, wireframe: true }));
    innerRing.rotation.x = Math.PI * 0.42; innerRing.rotation.y = Math.PI * 0.08; scene.add(innerRing);
    const resize = () => { const rect = canvas.getBoundingClientRect(); if (!rect.width || !rect.height) return; renderer.setSize(rect.width, rect.height, false); camera.aspect = rect.width / rect.height; camera.updateProjectionMatrix(); };
    resize(); const resizeObserver = new ResizeObserver(resize); resizeObserver.observe(canvas);
    let frame = 0; let alive = true; let visible = false;
    const render = () => { frame = 0; if (!alive || !visible || document.hidden) return; ring.rotation.z += 0.00042; innerRing.rotation.z -= 0.00028; if (points) points.rotation.y += 0.00008; renderer.render(scene, camera); frame = requestAnimationFrame(render); };
    const updateLoop = () => { if (alive && visible && !document.hidden && !frame) frame = requestAnimationFrame(render); else if ((!visible || document.hidden) && frame) { cancelAnimationFrame(frame); frame = 0; } };
    let intersectionObserver: IntersectionObserver | null = null;
    if ("IntersectionObserver" in window) { intersectionObserver = new IntersectionObserver((entries) => { visible = entries.some((entry) => entry.isIntersecting); updateLoop(); }, { rootMargin: "100px 0px" }); intersectionObserver.observe(canvas); }
    else { visible = true; updateLoop(); }
    document.addEventListener("visibilitychange", updateLoop);
    return () => { alive = false; if (frame) cancelAnimationFrame(frame); document.removeEventListener("visibilitychange", updateLoop); intersectionObserver?.disconnect(); resizeObserver.disconnect(); pointsGeometry?.dispose(); if (points) (points.material as THREE.Material).dispose(); ring.geometry.dispose(); (ring.material as THREE.Material).dispose(); innerRing.geometry.dispose(); (innerRing.material as THREE.Material).dispose(); renderer.dispose(); };
  }, [preferences.reducedMotion, preferences.simplified3d, preferences.cinematicEffects, preferences.particles]);
  return <canvas className="atmosphere-canvas" ref={canvasRef} aria-hidden="true" />;
}
