import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { usePreferences } from "@/contexts/PreferencesContext";
import { bumblebeeAttribution } from "@/data/siteContent";
import AudioControl from "@/components/AudioControl";
import MechanicalIcon from "@/components/MechanicalIcon";

gsap.registerPlugin(ScrollTrigger);
export default function BumblebeeScene() {
  const rootRef = useRef<HTMLElement>(null); const videoRef = useRef<HTMLVideoElement>(null); const durationRef = useRef(0);
  const [progress, setProgress] = useState(0); const [videoAvailable, setVideoAvailable] = useState(true);
  const { preferences } = usePreferences(); const poster = "/csi-assets/bumblebee-reference.jpg"; const staticMode = preferences.reducedMotion || preferences.simplified3d;
  useEffect(() => {
    const video = videoRef.current; if (!video || staticMode) return;
    const onMetadata = () => { durationRef.current = Number.isFinite(video.duration) ? video.duration : 0; };
    const onError = () => setVideoAvailable(false);
    video.addEventListener("loadedmetadata", onMetadata); video.addEventListener("error", onError); if (video.readyState >= 1) onMetadata();
    return () => { video.removeEventListener("loadedmetadata", onMetadata); video.removeEventListener("error", onError); };
  }, [staticMode]);
  useEffect(() => {
    const root = rootRef.current; if (!root || staticMode) return;
    const trigger = ScrollTrigger.create({ trigger: root, start: "top top", end: "bottom bottom", onUpdate: (self) => {
      const p = self.progress; setProgress(p); const video = videoRef.current;
      if (video && durationRef.current > 0) { const nextTime = Math.min(durationRef.current - 0.025, durationRef.current * p); if (Math.abs(video.currentTime - nextTime) > 0.035) video.currentTime = Math.max(0, nextTime); }
    } });
    return () => trigger.kill();
  }, [staticMode]);
  return (
    <section ref={rootRef} className={`transform-scene transform-scene--bumblebee ${staticMode ? "is-static" : ""}`} aria-label="Bumblebee rendered transformation sequence" style={{ "--scene-progress": progress } as React.CSSProperties}>
      <div className="scene-sticky"><div className="scene-grid" aria-hidden="true" />
        <div className="scene-copy scene-copy--left"><span className="eyebrow"><i /> BUMBLEBEE // EVENT DEPLOYMENT</span><h2>BRING THE<br />SPARK<span>.</span></h2><p>A rendered transformation sequence—scrubbed by your scroll. The original Events listings and registration links follow below.</p><AudioControl label="Bumblebee" fileName="bumblebees-transformation-3.mp3" available={true} stopWhenOutOfView /></div>
        <div className="scene-stage"><div className="scene-horizon" aria-hidden="true"><span /><span /><span /></div>
          {videoAvailable && !staticMode && <video ref={videoRef} className="sequence-video" src="/csi-assets/bumblebee-transform-sequence.mp4" poster={poster} preload="metadata" muted playsInline aria-label="Silent Bumblebee car-to-robot rendered sequence" style={{ transform: `scale(${1 + progress * 0.055})`, transformOrigin: "50% 52%" }} />}
          {(!videoAvailable || staticMode) && <img className="scene-poster" src={poster} alt="Bumblebee vehicle model reference, shown as a static fallback" />}
          <div className="scene-stage-overlay" aria-hidden="true"><span>RENDERED SEQUENCE // VISUAL PROTOTYPE</span><span>{videoAvailable && !staticMode ? `${Math.round(progress * 100)}%` : "STATIC VIEW"}</span></div>
          {staticMode && <div className="scene-fallback-note">STATIC VIEW // ANIMATION PAUSED BY YOUR DISPLAY PREFERENCE</div>}
          {!videoAvailable && <div className="scene-fallback-note">SEQUENCE UNAVAILABLE // STATIC PREVIEW</div>}
        </div>
        <div className="scene-copy scene-copy--right"><span className="scene-readout">{String(Math.round(progress * 100)).padStart(3, "0")}%</span><div className="scene-readout-caption">YELLOW ALERT<br />SEQUENCE</div><div className="scene-progress"><span style={{ transform: `scaleY(${Math.max(progress, 0.02)})` }} /></div><MechanicalIcon name="scroll" size={22} /></div>
        <div className="scene-bottomline"><span>SCROLL // CAR MODE → ROBOT MODE <MechanicalIcon name="scroll" size={14} /></span><span className="scene-attribution"><a href={bumblebeeAttribution.href} target="_blank" rel="noreferrer">STATIC VEHICLE MODEL REFERENCE · {bumblebeeAttribution.author} · {bumblebeeAttribution.license}</a><br />SEQUENCE IS GENERATED VIDEO, NOT A RIGGED MODEL</span></div>
      </div>
    </section>
  );
}
