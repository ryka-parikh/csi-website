import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import SiteShell from "./components/SiteShell";
import { ThemeProvider } from "./contexts/ThemeContext";
import { PreferencesProvider } from "./contexts/PreferencesContext";
import { lazy, Suspense } from "react";
const Home = lazy(() => import("./pages/Home"));
const Events = lazy(() => import("./pages/Events"));
const Team = lazy(() => import("./pages/Team"));
const Gallery = lazy(() => import("./pages/Gallery"));
const TechnicalSaturdays = lazy(() => import("./pages/TechnicalSaturdays"));
const Alumni = lazy(() => import("./pages/Alumni"));
const Newsletters = lazy(() => import("./pages/Newsletters"));
const Sponsors = lazy(() => import("./pages/Sponsors"));
const NotFound = lazy(() => import("./pages/NotFound"));
import { Route, Switch } from "wouter";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/index.html" component={Home} />
      <Route path="/team" component={Team} />
      <Route path="/team.php" component={Team} />
      <Route path="/events" component={Events} />
      <Route path="/events.php" component={Events} />
      <Route path="/gallery" component={Gallery} />
      <Route path="/gallery_event.php" component={Gallery} />
      <Route path="/technical-saturdays" component={TechnicalSaturdays} />
      <Route path="/technicalSaturday.php" component={TechnicalSaturdays} />
      <Route path="/alumni" component={Alumni} />
      <Route path="/alumni.php" component={Alumni} />
      <Route path="/newsletters" component={Newsletters} />
      <Route path="/newsletters.php" component={Newsletters} />
      <Route path="/sponsors" component={Sponsors} />
      <Route path="/sponsors.php" component={Sponsors} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
          <PreferencesProvider>
            <TooltipProvider>
              <Toaster />
              <SiteShell><Suspense fallback={<div role="status" aria-live="polite" style={{ minHeight: "55vh", display: "grid", placeContent: "center", gap: "10px", color: "#B2C0CC", textAlign: "center", fontFamily: "Rajdhani, sans-serif", letterSpacing: ".12em" }}><span>CSI KJSIT // AUTOBOT NETWORK</span><strong>ASSEMBLING INTERFACE...</strong></div>}><Router /></Suspense></SiteShell>
            </TooltipProvider>
          </PreferencesProvider>
        </ThemeProvider>
    </ErrorBoundary>
  );
}
