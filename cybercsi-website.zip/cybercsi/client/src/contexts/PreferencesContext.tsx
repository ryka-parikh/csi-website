import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";

export type Preferences = {
  masterMuted: boolean;
  sfxEnabled: boolean;
  characterVoices: boolean;
  volume: number;
  cinematicEffects: boolean;
  particles: boolean;
  reducedMotion: boolean;
  simplified3d: boolean;
};
const STORAGE_KEY = "csi-cybertron-preferences-v1";
const defaults: Preferences = { masterMuted: false, sfxEnabled: false, characterVoices: true, volume: 0.76, cinematicEffects: true, particles: true, reducedMotion: false, simplified3d: false };
type PreferencesContextValue = {
  preferences: Preferences;
  updatePreference: <K extends keyof Preferences>(key: K, value: Preferences[K]) => void;
  resetPreferences: () => void;
  claimAudio: (audio: HTMLAudioElement) => void;
  releaseAudio: (audio: HTMLAudioElement) => void;
  playMechanicalCue: () => void;
};
const PreferencesContext = createContext<PreferencesContextValue | null>(null);

function systemPrefersReducedMotion() {
  return typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches === true;
}
function loadPreferences(): Preferences {
  const systemDefault = { ...defaults, reducedMotion: systemPrefersReducedMotion() };
  if (typeof window === "undefined") return defaults;
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) return systemDefault;
    const parsed = JSON.parse(stored) as Partial<Preferences> | null;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return systemDefault;
    const restored = { ...systemDefault, ...parsed };
    restored.volume = typeof restored.volume === "number" ? Math.max(0, Math.min(1, restored.volume)) : defaults.volume;
    return restored;
  } catch { return systemDefault; }
}

export function PreferencesProvider({ children }: { children: ReactNode }) {
  const [preferences, setPreferences] = useState<Preferences>(loadPreferences);
  const activeAudio = useRef<HTMLAudioElement | null>(null);
  useEffect(() => {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(preferences)); } catch { /* storage may be blocked */ }
    document.documentElement.dataset.reducedMotion = String(preferences.reducedMotion);
    document.documentElement.dataset.cinematic = String(preferences.cinematicEffects);
    document.documentElement.dataset.particles = String(preferences.particles);
    document.documentElement.dataset.simplified3d = String(preferences.simplified3d);
  }, [preferences]);
  const updatePreference = useCallback(<K extends keyof Preferences>(key: K, value: Preferences[K]) => { setPreferences((current) => ({ ...current, [key]: value })); }, []);
  const resetPreferences = useCallback(() => setPreferences({ ...defaults, reducedMotion: systemPrefersReducedMotion() }), []);
  const claimAudio = useCallback((audio: HTMLAudioElement) => {
    if (activeAudio.current && activeAudio.current !== audio) { activeAudio.current.pause(); activeAudio.current.currentTime = 0; }
    activeAudio.current = audio;
  }, []);
  const releaseAudio = useCallback((audio: HTMLAudioElement) => { if (activeAudio.current === audio) activeAudio.current = null; }, []);
  const playMechanicalCue = useCallback(() => {
    if (preferences.masterMuted || !preferences.sfxEnabled || (activeAudio.current && !activeAudio.current.paused)) return;
    try {
      const Constructor = window.AudioContext || (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Constructor) return;
      const context = new Constructor(); const oscillator = context.createOscillator(); const gain = context.createGain();
      oscillator.type = "triangle"; oscillator.frequency.setValueAtTime(240, context.currentTime); oscillator.frequency.exponentialRampToValueAtTime(82, context.currentTime + 0.16);
      gain.gain.setValueAtTime(0.035, context.currentTime); gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.19);
      oscillator.connect(gain); gain.connect(context.destination); oscillator.start(); oscillator.stop(context.currentTime + 0.2);
      window.setTimeout(() => { void context.close(); }, 400);
    } catch { /* Unsupported audio APIs should not prevent Settings from opening. */ }
  }, [preferences.masterMuted, preferences.sfxEnabled]);
  const value = useMemo(() => ({ preferences, updatePreference, resetPreferences, claimAudio, releaseAudio, playMechanicalCue }), [preferences, updatePreference, resetPreferences, claimAudio, releaseAudio, playMechanicalCue]);
  return <PreferencesContext.Provider value={value}>{children}</PreferencesContext.Provider>;
}
export function usePreferences() {
  const context = useContext(PreferencesContext);
  if (!context) throw new Error("usePreferences must be used within PreferencesProvider");
  return context;
}
