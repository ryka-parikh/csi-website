import { useMemo, useState } from "react";
import { sponsorWebsiteLinks, sponsorsByYear } from "@/data/siteContent";
import { mediaForPageExcluding } from "@/data/media";
import { PageHero, SourceNote } from "@/components/PagePrimitives";
import MechanicalIcon from "@/components/MechanicalIcon";

const years = Object.keys(sponsorsByYear);
const logoOrder2023 = ["sponsorImages/1-1.png","sponsorImages/2-1.png","sponsorImages/3-1.png","sponsorImages/4-1.png","sponsorImages/5-1.png","sponsorImages/6-1.png","sponsorImages/7-1.png","sponsorImages/8-1.png","sponsorImages/9-1.png","sponsorImages/1-2.png","sponsorImages/3-2.png","sponsorImages/4-2.png","sponsorImages/5-2.png","sponsorImages/6-2.png","sponsorImages/7-2.png","sponsorImages/8-2.png","sponsorImages/9-2.png","sponsorImages/1-3.png","sponsorImages/3-3.png","sponsorImages/4-3.png","sponsorImages/5-3.png","sponsorImages/6-3.png","sponsorImages/7-3.png","sponsorImages/8-3.png","sponsorImages/9-3.png","sponsorImages/1-4.png","sponsorImages/3-4.png","sponsorImages/4-4.png","sponsorImages/5-4.png","sponsorImages/6-4.png","sponsorImages/7-4.png","sponsorImages/9-4.png"];
const filenameAliases: Record<string, string> = {
  "The Education Tree": "eductn tree.png", "Bell Mobile Accessories": "bell.png", "3P Consulting Engineers LLP": "3p eng.png", "Campus Times Pune": "campus times.png",
  "EazyDiner": "eazy dinner.png", "Rogue Code": "rouge code.png", "Second Tongue": "second tounge.png", "Hoodzilla": "hodzilla connect.png", "Smaaash": "smash.png",
  "ICICI Direct": "icicidirect.png", "Cinnamon Sticks": "cinnanmon sticks.png", "Voluptuous Vibe": "voluptous vibe ny.png", "Upcoming Engineer": "upcoming.png", "Fuschia Vkare": "fuschia.png",
  "Be the Mard": "bethemard.png", "No Escape": "nescape.png", "Axplorar Holidays": "axlorar.png", "1 Password": "1 passord.png", "Legit Energy Drink": "legitt drink.png",
};
function normalize(value: string) { return value.toLowerCase().replace(/[^a-z0-9]/g, ""); }

export default function Sponsors() {
  const [year, setYear] = useState(years[0]);
  const logos = useMemo(() => mediaForPageExcluding("sponsors", ["kartik.png", "logo", "social", "pfp"]), []);
  const names = sponsorsByYear[year] ?? [];
  function logoFor(name: string, index: number) {
    if (year === "2023") { const suffix = logoOrder2023[index]; return suffix ? logos.find((asset) => asset.sourcePath?.toLowerCase().endsWith(`/${suffix.toLowerCase()}`)) : undefined; }
    const yearPath = year === "2022" ? "/sponsor-2022/" : "/sponsors 2021/";
    const yearAssets = logos.filter((asset) => asset.sourcePath?.toLowerCase().includes(yearPath));
    const alias = filenameAliases[name];
    if (alias) return yearAssets.find((asset) => asset.sourcePath?.toLowerCase().endsWith(`/${alias.toLowerCase()}`));
    const target = normalize(name);
    return yearAssets.find((asset) => { const filename = normalize(asset.sourcePath?.split("/").pop()?.replace(/\.[^.]+$/, "") ?? ""); return filename && (filename.includes(target) || target.includes(filename)); });
  }
  return (
    <div className="page-content page-sponsors">
      <PageHero index="08" kicker="CSI KJSIT // PARTNERS" title="Built with our supporters." lead="An archive of organizations and brands credited on the public CSI KJSIT Sponsors page." tone="bumblebee" aside={<div className="page-hero-stat"><span>03</span><small>SPONSOR<br />ARCHIVE YEARS</small></div>} />
      <section className="sponsor-section section-wrap"><div className="sponsor-toolbar"><div><span className="eyebrow"><i /> RENAISSANCE & CHAPTER SUPPORTERS</span><h2>Support, remembered.</h2></div><div className="year-tabs" role="tablist" aria-label="Sponsor year">{years.map((item) => <button type="button" role="tab" aria-selected={year === item} className={year === item ? "is-active" : ""} key={item} onClick={() => setYear(item)}>{item}</button>)}</div></div>
        <div className="sponsor-grid">{names.map((name, index) => {
          const logo = logoFor(name, index); const href = sponsorWebsiteLinks[name];
          const content = <><span className="sponsor-logo">{logo ? <img src={logo.path} alt={`${name} original sponsor logo`} loading="lazy" /> : <b>{name}</b>}</span><span className="sponsor-name">{name}</span>{year === "2021" && name === "ICICI Direct" && <span className="sponsor-title-chip">TITLE SPONSOR</span>}{href && <span className="sponsor-external"><MechanicalIcon name="external" size={13} /></span>}</>;
          return href ? <a key={`${year}-${name}`} className="sponsor-card" href={href} target="_blank" rel="noreferrer" aria-label={`${name} sponsor website`}>{content}</a> : <div key={`${year}-${name}`} className="sponsor-card">{content}</div>;
        })}</div>
        <SourceNote>Sponsor names, their year selection and available original artwork are transcribed from the public reference. Original partner links are retained only where the source provides them; unavailable logo labels and destinations are not guessed.</SourceNote>
      </section>
    </div>
  );
}
