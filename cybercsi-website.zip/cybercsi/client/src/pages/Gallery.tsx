import { useEffect, useState } from "react";
import { mediaForPageExcluding } from "@/data/media";
import { PageHero, SourceNote } from "@/components/PagePrimitives";
import MechanicalIcon from "@/components/MechanicalIcon";

export default function Gallery() {
  const photos = mediaForPageExcluding("gallery", ["kartik.png", "logo", "pfp", "social"]);
  const [active, setActive] = useState<number | null>(null);
  useEffect(() => {
    if (active === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setActive(null);
      if (event.key === "ArrowRight") setActive((index) => index === null ? null : (index + 1) % photos.length);
      if (event.key === "ArrowLeft") setActive((index) => index === null ? null : (index + photos.length - 1) % photos.length);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [active, photos.length]);
  return (
    <div className="page-content page-gallery">
      <PageHero index="04" kicker="CSI KJSIT // ARCHIVE" title="In the frame." lead="Original photography and event images collected from the public CSI KJSIT Gallery page." tone="cybertron" aside={<div className="page-hero-stat"><span>{String(photos.length).padStart(2, "0")}</span><small>LOCAL SOURCE<br />IMAGES</small></div>} />
      <section className="gallery-section section-wrap"><div className="gallery-heading"><span className="eyebrow"><i /> SOURCE MEDIA // CSI KJSIT</span><span>SELECT AN IMAGE TO EXPAND <MechanicalIcon name="arrow" size={14} /></span></div>
        <div className="gallery-masonry">{photos.map((asset, index) => <button className={`gallery-tile gallery-tile--${index % 5}`} key={asset.path} type="button" onClick={() => setActive(index)} aria-label={`Expand CSI KJSIT gallery image ${index + 1}`}><img src={asset.path} alt={`CSI KJSIT event gallery photograph ${index + 1}`} loading="lazy" /><span className="gallery-caption"><small>CSI KJSIT // FRAME {String(index + 1).padStart(2, "0")}</small><MechanicalIcon name="external" size={15} /></span></button>)}</div>
        {photos.length === 0 && <div className="empty-catalogue"><span className="eyebrow">MEDIA LINK // UNAVAILABLE</span><p>The source site did not expose gallery files in the current public capture.</p></div>}
      </section>
      <SourceNote>Photo captions were not exposed in the public source page, so the original media is shown without invented event names.</SourceNote>
      {active !== null && photos[active] && <div className="lightbox" role="dialog" aria-modal="true" aria-label={`Gallery image ${active + 1}`} onClick={() => setActive(null)}><button type="button" className="icon-button lightbox-close" onClick={() => setActive(null)} aria-label="Close image"><MechanicalIcon name="close" size={22} /></button><button type="button" className="lightbox-arrow lightbox-arrow--left" onClick={(event) => { event.stopPropagation(); setActive((active + photos.length - 1) % photos.length); }} aria-label="Previous image"><MechanicalIcon name="arrow" /></button><img src={photos[active].path} alt={`CSI KJSIT event gallery image ${active + 1}`} onClick={(event) => event.stopPropagation()} /><button type="button" className="lightbox-arrow lightbox-arrow--right" onClick={(event) => { event.stopPropagation(); setActive((active + 1) % photos.length); }} aria-label="Next image"><MechanicalIcon name="arrow" /></button><span className="lightbox-count">FRAME {String(active + 1).padStart(2, "0")} / {String(photos.length).padStart(2, "0")}</span></div>}
    </div>
  );
}
