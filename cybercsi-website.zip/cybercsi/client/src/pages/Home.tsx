import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { Link } from "wouter";
import { homeContent, siteNav } from "@/data/siteContent";
import { mediaBySourcePath } from "@/data/media";
const Atmosphere = lazy(() => import("@/scenes/Atmosphere"));
import OptimusScene from "@/scenes/OptimusScene";
import MechanicalIcon from "@/components/MechanicalIcon";
import AudioControl from "@/components/AudioControl";
import { SectionTitle } from "@/components/PagePrimitives";
import { usePreferences } from "@/contexts/PreferencesContext";

function Initialization() {
  const [visible, setVisible] = useState(false);
  const { preferences } = usePreferences();
  useEffect(() => {
    let seen = false;
    try { seen = Boolean(window.sessionStorage.getItem("csi-cybertron-intro-seen")); } catch { /* session storage may be blocked */ }
    if (seen || preferences.reducedMotion) { setVisible(false); return; }
    setVisible(true);
    const timer = window.setTimeout(() => { setVisible(false); try { window.sessionStorage.setItem("csi-cybertron-intro-seen", "true"); } catch { /* no-op */ } }, 2450);
    return () => window.clearTimeout(timer);
  }, [preferences.reducedMotion]);
  function skip() { setVisible(false); try { window.sessionStorage.setItem("csi-cybertron-intro-seen", "true"); } catch { /* no-op */ } }
  if (!visible) return null;
  return <div className="initialization-screen" role="status" aria-live="polite"><div className="init-blueprint" aria-hidden="true"><span /><span /><span /><i /></div><div className="init-head" aria-hidden="true"><span className="init-eye init-eye--left" /><span className="init-eye init-eye--right" /></div><div className="init-lines"><span>CYBERTRONIAN INTERFACE SYSTEM</span><strong>CSI KJSIT</strong><small>INITIALIZING AUTOBOT NETWORK...</small></div><div className="init-progress"><span /></div><button className="init-skip" type="button" onClick={skip}>SKIP INTRO <MechanicalIcon name="arrow" size={14} /></button></div>;
}

export default function Home() {
  const building = mediaBySourcePath("images/kjsieit.jpg");
  const csiMark = mediaBySourcePath("images/CSI Logo 22-23.png");
  const somaiyaMark = mediaBySourcePath("images/Somaiya Logo(1).png");
  const heroVisual = useRef<HTMLDivElement>(null);
  const [atmosphereReady, setAtmosphereReady] = useState(false);
  useEffect(() => {
    const target = heroVisual.current;
    if (!target) return;
    if (!("IntersectionObserver" in window)) { setAtmosphereReady(true); return; }
    const observer = new IntersectionObserver((entries) => { if (entries.some((entry) => entry.isIntersecting)) { setAtmosphereReady(true); observer.disconnect(); } }, { rootMargin: "360px 0px" });
    observer.observe(target);
    return () => observer.disconnect();
  }, []);
  return (
    <>
      <Initialization />
      <div id="optimus-scene"><OptimusScene /></div>
      <section className="home-hero">
        <div ref={heroVisual} className="hero-visual" aria-label="K. J. Somaiya Institute of Technology, Sion">{building && <img src={building} alt="K. J. Somaiya Institute of Technology, Sion, Mumbai" />}<div className="hero-visual-shade" /><Suspense fallback={null}>{atmosphereReady && <Atmosphere />}</Suspense><div className="hero-visual-data"><span>LOCATION // SION, MUMBAI</span><span>CSI KJSIT // SION, MUMBAI</span></div><div className="hero-visual-mark"><span>CSI</span><small>STUDENT CHAPTER<br />EST. 2009</small></div><div className="hero-corner hero-corner--tl" /><div className="hero-corner hero-corner--br" /></div>
        <div className="hero-copy"><span className="eyebrow"><i /> COMPUTER SOCIETY OF INDIA // STUDENT’S CHAPTER</span><h1>SHARING<br /><em>KNOWLEDGE</em><br />SINCE 2009<span className="title-period">.</span></h1><p className="hero-lede">A community that turns curiosity into capability—through workshops, technical festivals, seminars and the people who build them together.</p><div className="hero-actions"><a href="#about" className="machined-button">DISCOVER CSI KJSIT <MechanicalIcon name="arrow" size={15} /></a><Link href="/events" className="quiet-link">EXPLORE CSI EVENTS <span>↗</span></Link></div><div className="hero-identifiers"><div><span className="eyebrow">INSTITUTION</span><strong>K. J. SOMAIYA INSTITUTE<br />OF TECHNOLOGY</strong></div><div><span className="eyebrow">CHAPTER</span><strong>COMPUTER SOCIETY<br />OF INDIA</strong></div></div></div>
        <div className="hero-index"><span>02 / 08</span><span>FIELD SYSTEM // ACTIVE</span><div className="hero-index-line" /></div>
      </section>
      <section className="intro-strip"><span className="eyebrow"><i /> AUTOBOT NETWORK // CSI KJSIT</span><p>Not a team, but a family.<br /><em>A technical community with room to grow.</em></p><AudioControl label="Optimus Prime" fileName="my-name-is-optimus-prime.mp3" available={true} compact stopWhenOutOfView /></section>
      <section className="home-about section-wrap" id="about"><SectionTitle index="01" eyebrow="THE INSTITUTE // KJSIT" title="Grounded in a real community.">The machine is only the metaphor. The work, people and achievements are CSI KJSIT’s.</SectionTitle><div className="about-split"><div className="about-photo-wrap"><div className="about-photo-frame">{building && <img src={building} alt="K. J. Somaiya Institute of Technology campus" loading="lazy" />}</div><div className="about-photo-caption"><span>INSTITUTE // SION</span><span>EST. 2009</span></div></div><div className="about-copy"><span className="eyebrow">{homeContent.institute.location}</span><h3>{homeContent.institute.title}</h3><p>{homeContent.institute.summary}</p><p>{homeContent.institute.detail}</p><div className="institution-marks">{csiMark && <img src={csiMark} alt="Computer Society of India logo" loading="lazy" />}{somaiyaMark && <img src={somaiyaMark} alt="Somaiya institutional mark" loading="lazy" />}</div><a className="text-link" href="https://kjsieit.somaiya.edu/en" target="_blank" rel="noreferrer">K. J. SOMAIYA INSTITUTE OF TECHNOLOGY <MechanicalIcon name="external" size={14} /></a></div></div></section>
      <section className="founding-band section-wrap"><div className="founding-year"><span className="eyebrow">CHAPTER ESTABLISHED</span><strong>{homeContent.origin.year}</strong><span>CSI STUDENTS’ CHAPTER</span></div><div className="founding-copy"><span className="eyebrow">{homeContent.origin.title}</span><p>{homeContent.origin.body}</p></div></section>
      <section className="about-csi section-wrap"><SectionTitle index="02" eyebrow="COMPUTER SOCIETY OF INDIA" title="Knowledge, shared forward." /><div className="about-csi-body"><span className="oversized-mark">CSI</span><p>{homeContent.aboutCsi.body}</p><Link href="/team" className="text-link">MEET THE 2024–25 TEAM <MechanicalIcon name="arrow" size={14} /></Link></div></section>
      <section className="voices-section section-wrap"><SectionTitle index="03" eyebrow="FROM THE INSTITUTE & CHAPTER" title="Words from the people who lead." /><div className="voices-list">{homeContent.statements.map((item, index) => { const image = mediaBySourcePath(item.image); return <article className="voice-card" key={item.name}><div className="voice-index">0{index + 1}</div><div className="voice-person">{image && <img src={image} alt="" loading="lazy" />}<div><strong>{item.name}</strong><span>{item.role}</span></div></div><div className="voice-copy"><span className="eyebrow">{item.group}</span><blockquote>“{item.quote}”</blockquote></div></article>; })}</div></section>
      <section className="home-routes section-wrap"><SectionTitle index="04" eyebrow="EXPLORE THE NETWORK" title="Choose your next destination." /><div className="route-grid">{siteNav.slice(1).map((item, index) => <Link key={item.href} href={item.href} className={`route-card route-card--${index}`}><span className="route-card-index">0{index + 1} // MODULE</span><MechanicalIcon name={item.icon} size={25} /><strong>{item.label}</strong><span>OPEN MODULE <MechanicalIcon name="arrow" size={14} /></span></Link>)}</div></section>
      <section className="contact-band section-wrap"><div><span className="eyebrow"><i /> REACH THE CHAPTER</span><h2>Questions?<br /><em>Contact CSI KJSIT.</em></h2></div><div className="contact-list">{homeContent.legacyContacts.map((contact) => <a key={contact.email} href={`mailto:${contact.email}`} className="contact-row"><span><strong>{contact.name}</strong><small>{contact.role} // {contact.phone}</small></span><span>{contact.email}</span><MechanicalIcon name="arrow" size={17} /></a>)}</div></section>
      <div className="last-line"><span>CSI KJSIT // SHARING KNOWLEDGE SINCE 2009</span><a href="#main-content">BACK TO TOP ↑</a></div>
    </>
  );
}
