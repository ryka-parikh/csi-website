import { alumniStories } from "@/data/siteContent";
import { PageHero, SourceNote } from "@/components/PagePrimitives";
import MechanicalIcon from "@/components/MechanicalIcon";

export default function Alumni() {
  return (
    <div className="page-content page-alumni">
      <PageHero index="06" kicker="CSI KJSIT // ALUMNI NETWORK" title="The legacy travels." lead="Words from our Alumni—former committee members on learning, leadership, teamwork and the CSI KJSIEIT experience." tone="optimus" aside={<div className="page-hero-stat"><span>06</span><small>STORIES<br />FROM THE ARCHIVE</small></div>} />
      <section className="alumni-section section-wrap"><div className="section-title"><div className="section-index">01</div><div><span className="eyebrow">WORDS FROM OUR ALUMNI</span><h2>What the journey leaves behind.</h2></div></div><div className="alumni-list">{alumniStories.map((story, index) => <details className="alumni-story" key={story.name} open={index === 0}><summary><span className="alumni-story-no">0{index + 1}</span><span className="alumni-story-person"><strong>{story.name}</strong><small>{story.role}</small></span><span className="alumni-story-initials">{story.name.split(" ").map((word) => word[0]).join("")}</span><span className="alumni-story-toggle"><span>READ TESTIMONIAL</span><MechanicalIcon name="chevron" size={18} /></span></summary><div className="alumni-story-content"><span className="eyebrow">CSI KJSIEIT // ALUMNI REFLECTION</span><blockquote>“{story.quote}”</blockquote></div></details>)}</div><SourceNote>Alumni names, tenure labels and testimonials are transcribed from the public CSI KJSIEIT Alumni page. Minor spacing and punctuation are normalized for readability.</SourceNote></section>
    </div>
  );
}
