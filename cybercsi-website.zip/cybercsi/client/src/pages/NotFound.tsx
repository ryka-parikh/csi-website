import { Link } from "wouter";
import MechanicalIcon from "@/components/MechanicalIcon";

export default function NotFound() {
  return <section className="not-found-page"><span className="eyebrow"><i /> ROUTE // NOT FOUND</span><strong>404</strong><h1>Signal lost.</h1><p>This route is not part of the CSI KJSIT interface archive.</p><Link href="/" className="machined-button">RETURN HOME <MechanicalIcon name="arrow" size={15} /></Link></section>;
}
