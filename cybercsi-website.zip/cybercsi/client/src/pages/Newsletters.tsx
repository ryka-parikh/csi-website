import { newsletters } from "@/data/siteContent";
import { PageHero } from "@/components/PagePrimitives";
import MechanicalIcon from "@/components/MechanicalIcon";

export default function Newsletters() {
  return (
    <div className="page-content page-newsletters">
      <PageHero index="07" kicker="CSI KJSIEIT // PUBLICATIONS" title="Dispatches from the network." lead="A home for chapter updates, ideas and stories—when the next issue is ready." tone="cybertron" aside={<div className="page-hero-stat"><span>07</span><small>TRANSMISSION<br />CHANNEL</small></div>} />
      <section className="newsletter-display section-wrap"><div className="newsletter-frame"><span className="eyebrow"><i /> NEWSLETTER TRANSMISSION</span><div className="newsletter-emblem"><MechanicalIcon name="newsletter" size={54} /><span>CSI</span></div><h2>{newsletters.status}</h2><p>CSI - KJSIEIT</p><div className="newsletter-status"><span><i /> SIGNAL // STANDBY</span><span>ISSUE ARCHIVE // NOT YET PUBLISHED</span></div></div><div className="newsletter-side"><span className="eyebrow">CHANNEL 07</span><p>The public source page lists “Coming Soon!” and does not expose downloadable issues or an archive. This page keeps that status rather than showing an out-of-date countdown.</p><a href="https://www.instagram.com/csi_kjsieit/?hl=en" target="_blank" rel="noreferrer" className="machined-button">FOLLOW CHAPTER UPDATES <MechanicalIcon name="external" size={14} /></a></div></section>
    </div>
  );
}
