import { useState } from "react";
import { coreTeam, subCoreTeam, teamGroups, teamContacts } from "@/data/siteContent";
import { mediaBySourcePath } from "@/data/media";
import MechanicalIcon from "@/components/MechanicalIcon";
import { PageHero, SourceNote } from "@/components/PagePrimitives";

type Member = { role: string; name: string; image: string; email?: string; socials?: string[] };
function MemberCard({ member, featured = false }: { member: Member; featured?: boolean }) {
  const [broken, setBroken] = useState(false);
  const image = mediaBySourcePath(member.image);
  return <article className={`member-card ${featured ? "is-featured" : ""}`}>
    <div className="member-portrait">{image && !broken ? <img src={image} alt={`${member.name}, ${member.role}`} loading="lazy" onError={() => setBroken(true)} /> : <span aria-hidden="true">{member.name.split(" ").map((word) => word[0]).join("").slice(0, 2)}</span>}<small>CSI // 24–25</small></div>
    <div className="member-info"><span className="eyebrow">{member.role}</span><h3>{member.name}</h3><div className="member-links">{member.email && <a href={`mailto:${member.email}`} aria-label={`Email ${member.name}`}><MechanicalIcon name="newsletter" size={14} /> EMAIL</a>}{member.socials?.map((url, index) => <a key={url} href={url} target="_blank" rel="noreferrer" aria-label={`${member.name} social profile ${index + 1}`}><MechanicalIcon name="external" size={13} /> {index === 0 ? "PROFILE" : "SOCIAL"}</a>)}</div></div>
  </article>;
}

export default function Team() {
  return (
    <div className="page-content page-team">
      <PageHero index="03" kicker="CSI KJSIT // PEOPLE" title="A team, built together." lead="Meet the student members listed for the 2024–25 CSI KJSIT committee and its sub-core." tone="optimus" aside={<div className="page-hero-stat"><span>24–25</span><small>COMMITTEE<br />TENURE</small></div>} />
      <section className="team-section section-wrap"><div className="section-title"><div className="section-index">01</div><div><span className="eyebrow">CORE COMMITTEE</span><h2>Core 2024–25</h2></div></div><div className="team-grid team-grid--core">{coreTeam.map((member) => <MemberCard key={member.name} member={member} featured />)}</div></section>
      <section className="team-section team-section--sub section-wrap"><div className="section-title"><div className="section-index">02</div><div><span className="eyebrow">SUB-CORE COMMITTEE</span><h2>Sub-Core 2024–25</h2></div></div><div className="team-grid team-grid--sub">{subCoreTeam.map((member) => <MemberCard key={`${member.role}-${member.name}`} member={member} />)}</div><SourceNote>Two source portraits were served as truncated image files. Those cards use initials rather than incorrect or substituted photographs.</SourceNote></section>
      <section className="teams-row section-wrap"><div className="section-title"><div className="section-index">03</div><div><span className="eyebrow">COMMITTEE GROUPS</span><h2>Teams within the team.</h2></div></div><div className="team-pill-list">{teamGroups.map((team, index) => <div key={team}><span>0{index + 1}</span><strong>{team}</strong><MechanicalIcon name="arrow" size={15} /></div>)}</div></section>
      <section className="team-contact section-wrap"><div><span className="eyebrow">REACH US // CONTACT</span><h2>Connect with the committee.</h2></div><div className="contact-list">{teamContacts.map((contact) => <a key={contact.email} href={`mailto:${contact.email}`} className="contact-row"><span><strong>{contact.name}</strong><small>{contact.role} // {contact.phone}</small></span><span>{contact.email}</span><MechanicalIcon name="arrow" size={17} /></a>)}</div></section>
      <SourceNote>These are the team roles and members visible on the public Team page. The source route does not expose a historical roster archive; no older names or roles have been added.</SourceNote>
    </div>
  );
}
