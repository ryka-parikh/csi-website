import { events } from "@/data/siteContent";
import { mediaForPageExcluding } from "@/data/media";
import BumblebeeScene from "@/scenes/BumblebeeScene";
import MechanicalIcon from "@/components/MechanicalIcon";
import { PageHero, SourceNote } from "@/components/PagePrimitives";

export default function Events() {
  const eventMedia = mediaForPageExcluding("events", ["kartik.png", "logo", "social"]).filter((asset) => asset.sourcePath?.toLowerCase().includes("/events_24/"));
  return (
    <>
      <BumblebeeScene />
      <div className="page-content page-events">
        <PageHero index="02" kicker="CSI KJSIT // EVENTS" title="Ideas meet action." lead="Workshops, technical challenges and shared experiences from the CSI KJSIT events archive." tone="bumblebee" aside={<div className="page-hero-stat"><span>{String(events.length).padStart(2, "0")}</span><small>LISTED EVENTS<br />SOURCE ARCHIVE</small></div>} />
        <div className="section-wrap events-intro"><div><span className="eyebrow"><i /> SOURCE LISTINGS // DATES AS PUBLISHED</span><h2>Make a move.<br /><em>Make it together.</em></h2></div><p>The event titles, descriptions, dates and registration destinations below are reproduced from CSI KJSIT’s public Events page. Dates are shown as listed in the source; the source does not include a year for these entries.</p></div>
        {eventMedia.length > 0 && <section className="events-media-band section-wrap"><div className="media-band-heading"><span className="eyebrow">ORIGINAL EVENT MEDIA</span><span>{String(eventMedia.length).padStart(2, "0")} SOURCE POSTERS</span></div><div className="events-media-strip">{eventMedia.slice(0, 8).map((asset, index) => <img key={asset.path} src={asset.path} alt={`Original CSI KJSIT event poster ${index + 1}`} loading="lazy" />)}</div></section>}
        <section className="events-list section-wrap"><div className="event-filterline"><span className="eyebrow"><i /> {String(events.length).padStart(2, "0")} SOURCE RECORDS</span><span className="eyebrow">ORIGINAL REGISTRATION LINKS</span></div>
          <div className="event-grid">{events.map((event, index) => <article className="event-card" key={event.title}>
            <div className="event-card-top"><span className="event-card-index">EVT // {String(index + 1).padStart(2, "0")}</span><span className="event-card-signal"><i /><i /><i /></span></div>
            <div className="event-card-body"><span className="eyebrow">CSI KJSIT // EVENT LISTING</span><h3>{event.title}</h3><p>{event.description}</p></div>
            <div className="event-meta">{event.date && <div><small>DATE</small><strong>{event.date}</strong></div>}{event.time && <div><small>TIME</small><strong>{event.time}</strong></div>}</div>
            <a className="event-register" href={event.register} target="_blank" rel="noreferrer"><span>OPEN ORIGINAL REGISTRATION</span><MechanicalIcon name="external" size={15} /></a>
          </article>)}</div>
          <SourceNote>Registration destinations are the original Google Forms linked from the public CSI KJSIT page; their present availability is controlled by the form owners.</SourceNote>
        </section>
        <div className="page-outro section-wrap"><span className="eyebrow">NEXT MODULE // GALLERY</span><p>Moments captured<br />in the field.</p><a href="/gallery" className="machined-button">VIEW THE GALLERY <MechanicalIcon name="arrow" size={15} /></a></div>
      </div>
    </>
  );
}
