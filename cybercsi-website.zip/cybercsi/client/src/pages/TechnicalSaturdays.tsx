import { technicalSaturday } from "@/data/siteContent";
import { mediaForPageExcluding } from "@/data/media";
import { PageHero, SourceNote } from "@/components/PagePrimitives";
import MechanicalIcon from "@/components/MechanicalIcon";

export default function TechnicalSaturdays() {
  const media = mediaForPageExcluding("technical-saturdays", ["kartik.png", "logo", "social"]);
  return (
    <div className="page-content page-technical">
      <PageHero index="05" kicker="CSI KJSIT // LEARNING SERIES" title="Technical Saturday." lead="A focused space for technical discovery, with hardware and software pathways in the CSI KJSIT archive." tone="cybertron" aside={<div className="page-hero-stat"><span>TS</span><small>WEEKEND<br />MODULE</small></div>} />
      <section className="technical-section section-wrap"><div className="technical-toolbar"><div><span className="eyebrow"><i /> SESSION CATALOGUE</span><h2>Topics in the public archive.</h2></div><div className="filter-tabs" aria-label="Technical Saturday categories shown on the public reference">{technicalSaturday.filters.map((filter) => <span className="filter-chip" key={filter}>{filter}</span>)}</div></div>
        <div className="technical-display"><div className="technical-display-index"><span>REFERENCE CATEGORIES</span><span>CSI KJSIT</span></div><div className="technical-gear" aria-hidden="true"><MechanicalIcon name="technical" size={62} /></div><h3>Knowledge in motion.</h3><p>{technicalSaturday.note}</p><div className="technical-focus"><span>01 // HARDWARE</span><span>02 // SOFTWARE</span></div>
          {media.length > 0 && <div className="technical-original-media">{media.slice(0, 4).map((asset) => <img key={asset.path} src={asset.path} alt="Original CSI KJSIT Technical Saturday media" loading="lazy" />)}</div>}
        </div><SourceNote>The public reference lists All, Hardware and Software categories but does not expose associated session records or details. These are preserved as source labels rather than misleading interactive filters.</SourceNote>
      </section>
      <div className="page-outro section-wrap"><span className="eyebrow">NEXT MODULE // ALUMNI</span><p>Learn from the<br />ones who came before.</p><a href="/alumni" className="machined-button">READ THEIR STORIES <MechanicalIcon name="arrow" size={15} /></a></div>
    </div>
  );
}
