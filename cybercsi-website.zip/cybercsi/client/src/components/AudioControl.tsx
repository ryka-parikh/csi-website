import { useEffect, useRef, useState } from "react";
import { usePreferences } from "@/contexts/PreferencesContext";
import MechanicalIcon from "./MechanicalIcon";

type PlaybackState = "idle" | "playing" | "paused" | "unavailable";
type AudioControlProps = { label: string; fileName: "my-name-is-optimus-prime.mp3" | "bumblebees-transformation-3.mp3"; available?: boolean; compact?: boolean; stopWhenOutOfView?: boolean };
export default function AudioControl({ label, fileName, available = false, compact = false, stopWhenOutOfView = false }: AudioControlProps) {
  const audioRef = useRef<HTMLAudioElement>(null); const wrapperRef = useRef<HTMLDivElement>(null); const stopping = useRef(false);
  const [state, setState] = useState<PlaybackState>(available ? "idle" : "unavailable"); const [playbackError, setPlaybackError] = useState(false);
  const { preferences, claimAudio, releaseAudio } = usePreferences();
  useEffect(() => { setState(available ? "idle" : "unavailable"); setPlaybackError(false); }, [available]);
  useEffect(() => {
    const audio = audioRef.current; if (!audio) return;
    if (preferences.masterMuted || !preferences.characterVoices || !available) { if (!audio.paused) { audio.pause(); setState("paused"); } releaseAudio(audio); }
    audio.volume = preferences.volume;
  }, [preferences.masterMuted, preferences.characterVoices, preferences.volume, available, releaseAudio]);
  useEffect(() => { const audio = audioRef.current; return () => { if (audio) { audio.pause(); releaseAudio(audio); } }; }, [releaseAudio]);
  useEffect(() => {
    if (!stopWhenOutOfView || !("IntersectionObserver" in window)) return;
    const wrapper = wrapperRef.current; const audio = audioRef.current; if (!wrapper || !audio) return;
    const observer = new IntersectionObserver((entries) => { if (entries.some((entry) => entry.isIntersecting) || audio.paused) return; audio.pause(); setState("paused"); releaseAudio(audio); }, { threshold: 0.05 });
    observer.observe(wrapper); return () => observer.disconnect();
  }, [stopWhenOutOfView, available, releaseAudio]);
  function canPlay() { return Boolean(audioRef.current && available && !preferences.masterMuted && preferences.characterVoices); }
  async function playFromStart() {
    const audio = audioRef.current; if (!audio || !canPlay()) return;
    claimAudio(audio); audio.currentTime = 0; audio.volume = preferences.volume; setPlaybackError(false);
    try { await audio.play(); setState("playing"); } catch { setState("idle"); setPlaybackError(true); releaseAudio(audio); }
  }
  async function togglePlayback() {
    const audio = audioRef.current; if (!audio || !canPlay()) return;
    if (!audio.paused) { audio.pause(); setState("paused"); releaseAudio(audio); return; }
    claimAudio(audio); audio.volume = preferences.volume; setPlaybackError(false); if (audio.ended) audio.currentTime = 0;
    try { await audio.play(); setState("playing"); } catch { setState("idle"); setPlaybackError(true); releaseAudio(audio); }
  }
  function stopPlayback() {
    const audio = audioRef.current; if (!audio) return;
    stopping.current = true; audio.pause(); audio.currentTime = 0; releaseAudio(audio); setState(available ? "idle" : "unavailable"); setPlaybackError(false);
  }
  const isUnavailable = state === "unavailable" || !available; const blocked = preferences.masterMuted || !preferences.characterVoices; const disabled = isUnavailable || blocked;
  const playLabel = isUnavailable ? `Audio unavailable — upload ${fileName}` : blocked ? preferences.masterMuted ? "Master audio is muted in Settings" : "Character voices are disabled in Settings" : playbackError ? `Playback issue — retry ${label}` : `${state === "playing" ? "Pause" : state === "paused" ? "Resume" : "Play"} ${label}`;
  return (
    <div ref={wrapperRef} className={`audio-control ${compact ? "audio-control--compact" : ""}`}>
      <audio ref={audioRef} src={available ? `/audio/${fileName}` : undefined} preload="none"
        onPlay={() => { stopping.current = false; setPlaybackError(false); setState("playing"); }}
        onPause={(event) => { if (stopping.current) { stopping.current = false; return; } if (!event.currentTarget.ended && state !== "unavailable") setState("paused"); }}
        onEnded={(event) => { event.currentTarget.currentTime = 0; setState("idle"); releaseAudio(event.currentTarget); }}
        onError={(event) => { setPlaybackError(true); setState(available ? "idle" : "unavailable"); releaseAudio(event.currentTarget); }} />
      <div className="voice-module">
        <button type="button" className={`voice-button ${state === "playing" ? "is-playing" : ""} ${isUnavailable ? "is-unavailable" : ""}`} onClick={togglePlayback} disabled={disabled} aria-label={playLabel} title={playLabel}>
          <span className="voice-icon"><MechanicalIcon name={state === "playing" ? "audio" : "signal"} size={18} /></span>
          {!compact && <span className="voice-copy"><strong>{label}</strong><small>{isUnavailable ? "VOICE FILE NOT LOADED" : playbackError ? "PLAYBACK ISSUE // PRESS TO RETRY" : state === "playing" ? "PLAYING // CLICK TO PAUSE" : state === "paused" ? "PAUSED // CLICK TO RESUME" : "VOICE CONTROL // READY"}</small></span>}
          <span className="waveform" aria-hidden="true">{Array.from({ length: 5 }, (_, index) => <i key={index} />)}</span>
        </button>
        <div className="voice-actions" aria-label={`${label} audio actions`}><button type="button" onClick={stopPlayback} disabled={isUnavailable || blocked} aria-label={`Stop ${label}`} title={`Stop ${label}`}><MechanicalIcon name="stop" size={14} /></button><button type="button" onClick={() => void playFromStart()} disabled={isUnavailable || blocked} aria-label={`Replay ${label}`} title={`Replay ${label}`}><MechanicalIcon name="replay" size={14} /></button></div>
      </div>
      <span className="sr-only" aria-live="polite">{isUnavailable ? `${label} audio unavailable. Upload ${fileName} to enable.` : playbackError ? `${label} audio could not start. Activate the play control to retry.` : state}</span>
    </div>
  );
}
