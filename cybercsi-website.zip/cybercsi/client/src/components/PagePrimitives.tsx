import type { ReactNode } from "react";
import MechanicalIcon from "./MechanicalIcon";

export function PageHero({ index, kicker, title, lead, tone = "optimus", aside }: { index: string; kicker: string; title: string; lead: string; tone?: string; aside?: ReactNode }) {
  return (
    <section className={`page-hero tone-${tone}`}>
      <div className="page-hero-main"><span className="eyebrow"><i /> {kicker}</span><h1>{title}</h1><p>{lead}</p></div>
      <div className="page-hero-aside">{aside ?? <span className="page-index">{index}</span>}</div>
      <div className="page-hero-index"><span>{index}</span><span>CSI KJSIT // SION, MUMBAI</span></div>
    </section>
  );
}

export function SectionTitle({ index, eyebrow, title, children }: { index?: string; eyebrow?: string; title: string; children?: ReactNode }) {
  return <div className="section-title"><div className="section-index">{index ?? "//"}</div><div><span className="eyebrow">{eyebrow ?? "CSI KJSIT"}</span><h2>{title}</h2>{children && <p>{children}</p>}</div></div>;
}

export function ActionLink({ href, children, external = false, className = "" }: { href: string; children: ReactNode; external?: boolean; className?: string }) {
  return <a className={`action-link ${className}`} href={href} {...(external ? { target: "_blank", rel: "noreferrer" } : {})}>{children}<MechanicalIcon name={external ? "external" : "arrow"} size={15} /></a>;
}

export function SourceNote({ children }: { children: ReactNode }) {
  return <p className="source-note"><MechanicalIcon name="signal" size={14} /><span>{children}</span></p>;
}
