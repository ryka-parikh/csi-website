import { useCallback, useEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { usePreferences } from "@/contexts/PreferencesContext";
import { siteNav, socialLinks, sketchfabAttribution, bumblebeeAttribution } from "@/data/siteContent";
import MechanicalIcon from "./MechanicalIcon";
import SettingsPanel from "./SettingsPanel";

type Props = { children: ReactNode };
const legacyRoutes: Record<string, string> = { "/team.php": "/team", "/events.php": "/events", "/gallery_event.php": "/gallery", "/technicalSaturday.php": "/technical-saturdays", "/alumni.php": "/alumni", "/newsletters.php": "/newsletters", "/sponsors.php": "/sponsors" };
function BrandMark() {
  return <Link href="/" className="brand-lockup" aria-label="CSI KJSIT home"><span className="brand-mark" aria-hidden="true"><i /><b /><em /></span><span className="brand-wording"><strong>CSI KJSIT</strong><small>CYBERTRONIAN INTERFACE SYSTEM</small></span></Link>;
}
function ScrollMeter() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    let frame = 0;
    const update = () => { cancelAnimationFrame(frame); frame = requestAnimationFrame(() => { const total = document.documentElement.scrollHeight - window.innerHeight; setProgress(total > 0 ? Math.min(100, Math.max(0, window.scrollY / total * 100)) : 0); }); };
    update(); window.addEventListener("scroll", update, { passive: true }); window.addEventListener("resize", update);
    return () => { cancelAnimationFrame(frame); window.removeEventListener("scroll", update); window.removeEventListener("resize", update); };
  }, []);
  return <div className="scroll-meter" aria-hidden="true"><span style={{ transform: `scaleX(${progress / 100})` }} /></div>;
}
export default function SiteShell({ children }: Props) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { playMechanicalCue } = usePreferences();
  const settingsTrigger = useRef<HTMLButtonElement>(null);
  const wasSettingsOpen = useRef(false);
  useEffect(() => setMobileOpen(false), [location]);
  useEffect(() => { if (wasSettingsOpen.current && !settingsOpen) settingsTrigger.current?.focus(); wasSettingsOpen.current = settingsOpen; }, [settingsOpen]);
  const openSettings = useCallback(() => { playMechanicalCue(); setSettingsOpen(true); }, [playMechanicalCue]);
  const closeSettings = useCallback(() => setSettingsOpen(false), []);
  const current = legacyRoutes[location] ?? location;
  return (
    <div className="site-frame">
      <ScrollMeter /><a className="skip-link" href="#main-content">Skip to content</a>
      <header className="site-header"><div className="header-inner"><BrandMark />
        <nav className={`main-nav ${mobileOpen ? "is-open" : ""}`} aria-label="Primary navigation">{siteNav.map((item) => <Link key={item.href} href={item.href} className={`nav-link ${current === item.href ? "is-active" : ""}`} aria-current={current === item.href ? "page" : undefined} onClick={() => setMobileOpen(false)}><MechanicalIcon name={item.icon} size={16} /><span>{item.label}</span></Link>)}</nav>
        <div className="header-tools"><button ref={settingsTrigger} type="button" className="icon-button settings-launch" onClick={openSettings} aria-label="Open Settings" title="Settings"><MechanicalIcon name="settings" size={19} /><span className="settings-label">Settings</span></button><button type="button" className="icon-button menu-launch" onClick={() => setMobileOpen((open) => !open)} aria-label={mobileOpen ? "Close navigation" : "Open navigation"} aria-expanded={mobileOpen}><MechanicalIcon name={mobileOpen ? "close" : "menu"} size={21} /></button></div>
      </div><div className="header-status"><span><i /> AUTOBOT NETWORK // ONLINE</span><span>CSI KJSIT <b>·</b> SION, MUMBAI</span></div></header>
      <main id="main-content" tabIndex={-1}>{children}</main>
      <footer className="site-footer"><div className="footer-main">
        <div className="footer-brand"><BrandMark /><p>Computer Society of India<br />K. J. Somaiya Institute of Technology<br />Sion, Mumbai</p><a href="https://kjsieit.somaiya.edu/en" target="_blank" rel="noreferrer" className="text-link">VISIT COLLEGE WEBSITE <MechanicalIcon name="external" size={14} /></a></div>
        <div className="footer-column"><span className="eyebrow">NAVIGATION</span>{siteNav.slice(1).map((item) => <Link key={item.href} href={item.href}>{item.label}</Link>)}</div>
        <div className="footer-column"><span className="eyebrow">CONNECT</span>{socialLinks.slice(0, 4).map((link) => <a key={link.label} href={link.href} target="_blank" rel="noreferrer">{link.label}<MechanicalIcon name="external" size={13} /></a>)}</div>
        <div className="footer-column footer-credit"><span className="eyebrow">MODEL & IMAGE CREDITS</span><p>{sketchfabAttribution.title}</p><a href={sketchfabAttribution.href} target="_blank" rel="noreferrer">{sketchfabAttribution.author} · {sketchfabAttribution.license}<MechanicalIcon name="external" size={13} /></a><p>{bumblebeeAttribution.title} (static poster reference)</p><a href={bumblebeeAttribution.href} target="_blank" rel="noreferrer">{bumblebeeAttribution.author} · {bumblebeeAttribution.license}<MechanicalIcon name="external" size={13} /></a><small>The Bumblebee video is a generated visual prototype, not a rigged 3D model.</small></div>
      </div><div className="footer-bottom"><span>© CSI KJSIT · STUDENT’S CHAPTER</span><span>DESIGN SYSTEM // CYBERTRONIAN INTERFACE</span><a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noreferrer">CC BY 4.0 ATTRIBUTION<MechanicalIcon name="external" size={12} /></a></div></footer>
      <SettingsPanel open={settingsOpen} onClose={closeSettings} />
    </div>
  );
}
