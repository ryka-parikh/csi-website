import type { ReactNode, SVGProps } from "react";

export type IconName =
  | "home" | "events" | "team" | "gallery" | "technical" | "alumni" | "newsletter"
  | "sponsors" | "search" | "settings" | "audio" | "mute" | "close" | "scroll"
  | "arrow" | "external" | "chevron" | "signal" | "spark" | "menu" | "stop" | "replay";

type Props = SVGProps<SVGSVGElement> & { name: IconName; size?: number };

export default function MechanicalIcon({ name, size = 20, ...props }: Props) {
  const common = { fill: "none", stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "square" as const, strokeLinejoin: "miter" as const };
  const shapes: Record<IconName, ReactNode> = {
    home: <><path d="M3 10.5 12 3l9 7.5v10H3z"/><path d="M9 20v-6h6v6M3 10.5h18"/></>,
    events: <><path d="M4 5h16v16H4zM7 3v4M17 3v4M4 9h16"/><path d="m8 14 2 2 5-5"/></>,
    team: <><path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM4 20v-1a7 7 0 0 1 14 0v1z"/><path d="M17 5a3 3 0 0 1 0 6M20 20v-1a6 6 0 0 0-3-5"/></>,
    gallery: <><path d="M3 4h18v16H3z"/><path d="m4 18 5-6 4 4 3-3 5 5"/><circle cx="9" cy="8" r="1.5"/></>,
    technical: <><path d="M14 6a5 5 0 0 0 5.5 6.8l-8.8 8.8-4.2-4.2 8.8-8.8A5 5 0 0 0 8.5 3L12 6.5z"/><path d="m5 17 2 2"/></>,
    alumni: <><path d="M4 7h16M4 12h11M4 17h7"/><path d="m17 14 3 3-3 3"/></>,
    newsletter: <><path d="M5 3h11l4 4v14H5z"/><path d="M15 3v5h5M8 12h8M8 16h8"/></>,
    sponsors: <><path d="m12 3 7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6z"/><path d="m9 11 2 2 4-4"/></>,
    search: <><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/></>,
    settings: <><path d="M9 3h6l.7 2.1 2 1.2 2.1-.7 3 5.2-1.5 1.5v2.4l1.5 1.5-3 5.2-2.1-.7-2 1.2L15 24H9l-.7-2.1-2-1.2-2.1.7-3-5.2 1.5-1.5v-2.4L1.7 10.8l3-5.2 2.1.7 2-1.2z" transform="translate(0 -1.5) scale(.93)"/><circle cx="12" cy="12" r="3.2"/></>,
    audio: <><path d="M3 10h3l4-4v12l-4-4H3z"/><path d="M14 9a4 4 0 0 1 0 6M17 6a8 8 0 0 1 0 12"/></>,
    mute: <><path d="M3 10h3l4-4v12l-4-4H3z"/><path d="m15 9 6 6m0-6-6 6"/></>,
    close: <><path d="m5 5 14 14M19 5 5 19"/><path d="M3 3h5M16 3h5M3 21h5M16 21h5"/></>,
    scroll: <><path d="M12 3v17M6 14l6 6 6-6"/><path d="M4 4h4M16 4h4"/></>,
    arrow: <><path d="M4 12h15M13 5l7 7-7 7"/></>,
    external: <><path d="M13 4h7v7M20 4 11 13"/><path d="M17 13v6H4V6h6"/></>,
    chevron: <><path d="m7 9 5 5 5-5"/></>,
    signal: <><path d="M3 18h2v3H3zM8 14h2v7H8zM13 9h2v12h-2zM18 4h2v17h-2z"/></>,
    spark: <><path d="m12 2 1.6 6.4L20 10l-6.4 1.6L12 18l-1.6-6.4L4 10l6.4-1.6z"/><path d="m19 17 .7 2.3L22 20l-2.3.7L19 23l-.7-2.3L16 20l2.3-.7z"/></>,
    menu: <><path d="M3 6h18M3 12h18M3 18h18"/><path d="M3 3h3v3H3zM18 18h3v3h-3z"/></>,
    stop: <><path d="M6 6h12v12H6z"/><path d="M3 3h4M17 3h4M3 21h4M17 21h4"/></>,
    replay: <><path d="M4 10a8 8 0 1 1 .5 6.2"/><path d="M4 4v6h6"/><path d="M12 8v4l3 2"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" {...common} {...props}>{shapes[name]}</svg>;
}
