import { useCallback, useEffect, useRef, useState } from "react";
import { usePreferences } from "@/contexts/PreferencesContext";
import MechanicalIcon from "./MechanicalIcon";

type Props = { open: boolean; onClose: () => void };
type ToggleProps = { title: string; detail: string; checked: boolean; onChange: (value: boolean) => void };
function ToggleRow({ title, detail, checked, onChange }: ToggleProps) {
  return <div className="setting-row"><div className="setting-copy"><strong>{title}</strong><span>{detail}</span></div><button className={`mechanical-switch ${checked ? "is-on" : ""}`} role="switch" type="button" aria-checked={checked} aria-label={title} onClick={() => onChange(!checked)}><span /></button></div>;
}
export default function SettingsPanel({ open, onClose }: Props) {
  const { preferences, updatePreference, resetPreferences } = usePreferences();
  const [closing, setClosing] = useState(false);
  const closeButton = useRef<HTMLButtonElement>(null);
  const panel = useRef<HTMLElement>(null);
  const closeTimer = useRef<number | undefined>(undefined);
  const beginClose = useCallback(() => {
    if (preferences.reducedMotion) { onClose(); return; }
    setClosing(true); window.clearTimeout(closeTimer.current); closeTimer.current = window.setTimeout(onClose, 520);
  }, [onClose, preferences.reducedMotion]);
  useEffect(() => {
    if (!open) return;
    setClosing(false);
    const focusTimer = window.setTimeout(() => closeButton.current?.focus(), 120);
    const previousOverflow = document.body.style.overflow; document.body.style.overflow = "hidden";
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") { event.preventDefault(); beginClose(); return; }
      if (event.key !== "Tab") return;
      const focusable = panel.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),a[href],[tabindex]:not([tabindex="-1"])');
      if (!focusable?.length) { event.preventDefault(); return; }
      const first = focusable[0]; const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKey);
    return () => { window.clearTimeout(focusTimer); document.removeEventListener("keydown", onKey); document.body.style.overflow = previousOverflow; };
  }, [open, beginClose]);
  useEffect(() => () => window.clearTimeout(closeTimer.current), []);
  if (!open) return null;
  return (
    <div className={`settings-layer ${closing ? "is-closing" : ""}`}>
      <button className="settings-backdrop" aria-label="Close system configuration" onClick={beginClose} />
      <section ref={panel} className="settings-panel" role="dialog" aria-modal="true" aria-labelledby="settings-title" data-reduced-motion={preferences.reducedMotion}>
        <div className="settings-armor settings-armor--top" aria-hidden="true" /><div className="settings-armor settings-armor--left" aria-hidden="true" /><div className="settings-armor settings-armor--right" aria-hidden="true" />
        <div className="settings-panel-content">
          <div className="settings-topline"><span className="eyebrow"><i /> SYSTEM // PREFERENCES</span><button ref={closeButton} type="button" className="icon-button settings-close" onClick={beginClose} aria-label="Close settings"><MechanicalIcon name="close" /></button></div>
          <h2 id="settings-title">CYBERTRONIAN SYSTEM CONFIGURATION</h2><p className="settings-subtitle">Adjust the interface. Your settings stay on this device.</p>
          <div className="settings-group settings-group--audio"><div className="settings-group-title"><MechanicalIcon name="audio" size={16} /><span>AUDIO SYSTEMS</span></div>
            <ToggleRow title="Master mute" detail="Silence all character audio and interface cues." checked={preferences.masterMuted} onChange={(v) => updatePreference("masterMuted", v)} />
            <ToggleRow title="Mechanical sound effects" detail="Enable a brief system activation cue; no sound plays by default." checked={preferences.sfxEnabled} onChange={(v) => updatePreference("sfxEnabled", v)} />
            <ToggleRow title="Character voice controls" detail="Allow Optimus Prime and Bumblebee voice files when uploaded." checked={preferences.characterVoices} onChange={(v) => updatePreference("characterVoices", v)} />
            <label className="range-row"><span className="setting-copy"><strong>Playback volume</strong><span>Applies to character voice clips.</span></span><input type="range" min="0" max="1" step="0.05" value={preferences.volume} onChange={(event) => updatePreference("volume", Number(event.target.value))} aria-label="Playback volume" /><output>{Math.round(preferences.volume * 100)}%</output></label>
          </div>
          <div className="settings-group settings-group--visual"><div className="settings-group-title"><MechanicalIcon name="spark" size={16} /><span>VISUAL EXPERIENCE</span></div>
            <ToggleRow title="Cinematic effects" detail="Blueprint scanning lines, particle accents and energy illumination." checked={preferences.cinematicEffects} onChange={(v) => updatePreference("cinematicEffects", v)} />
            <ToggleRow title="Atmospheric particles" detail="Toggle the background particle field independently." checked={preferences.particles} onChange={(v) => updatePreference("particles", v)} />
            <ToggleRow title="Reduced motion" detail="Open Settings immediately and simplify animated transitions." checked={preferences.reducedMotion} onChange={(v) => updatePreference("reducedMotion", v)} />
            <ToggleRow title="Simplified 3D" detail="Reduce atmospheric rendering for slower devices or battery life." checked={preferences.simplified3d} onChange={(v) => updatePreference("simplified3d", v)} />
          </div>
          <div className="settings-bottom"><button type="button" className="text-button" onClick={resetPreferences}>RETURN TO DEFAULT EXPERIENCE <span>↺</span></button><span className="system-online"><i /> SYSTEM CONFIGURATION // ONLINE</span></div>
        </div>
      </section>
    </div>
  );
}
