# CSI KJSIT — Cybertronian Interface

## Scope and implementation approach

Build a new, static-first React site in the initialized Manus project. This is a reconstruction from the public CSI KJSIT reference—not a modification of the live website or an edit of a source repository (none was supplied). Preserve verified public content and retrieve its original photos, team portraits, event posters, sponsor logos, registration links and social destinations. Keep route equivalents for Home (`/` and `/index.html`), Team, Events, Gallery, Technical Saturdays, Alumni, Newsletters and Sponsors, including the legacy `.php` aliases. Public extraction of some pages is incomplete; never invent missing CSI content or claim to preserve unavailable backend behavior.

Use React 19, TypeScript, Vite and Wouter with the initialized static-only runtime (no application server or database). `client/src/App.tsx` owns routes; reusable UI components are under `client/src/components/`; verified records under `client/src/data/`; scene control under `client/src/scenes/`; preferences under `client/src/contexts/`; design tokens and responsive/reduced-motion styling in `client/src/index.css`; public files and route manifest under `client/public/`.

Home is the Optimus flagship with the exact skippable initialization text and a normal-scroll, reversible transformation section before actual CSI introduction/content. The public Sketchfab entry [“Bumblebee - Optimus Prime Transform Animation” by DIO](https://sketchfab.com/3d-models/bumblebee-optimus-prime-transform-animation-35f9cb09b1b248c7bd6b12912ac8cd3a) reports one animation and CC BY 4.0; its unauthenticated download endpoint returns 401, but the public viewer API documents exact `seekTo(seconds)`. Use the hosted viewer and its official API if it can be made to load and the single animation is confirmed as the vehicle-to-robot transformation. Give visible model/author/license attribution. GSAP ScrollTrigger maps both scroll directions to the animation time. Use Three.js for lightweight environment/atmosphere effects, not as a substitute for the supplied character model; do not imply the hosted viewer is a locally rigged Three.js asset. If the viewer fails or its animation is not a vehicle transformation, replace that scene with an honestly labeled rendered-sequence prototype, not a static truck/robot crossfade.

Events keeps actual CSI Events/registration information and has a distinct Bumblebee scene. The checked Bumblebee Sketchfab candidates are static (`animationCount: 0`), so no articulated Bumblebee animation has been found. Use a short rendered-sequence prototype generated from the openly licensed CC BY Bumblebee model reference, then scrub the actual video timeline with GSAP and ordinary reversible scroll. Clearly label it `RENDERED TRANSFORMATION SEQUENCE // VISUAL PROTOTYPE`; never imply a fully articulated 3D character. If a suitable licensed animated model is later found, the integration can use it instead. The public reference includes full 1920×1080 Sketchfab character reference images; project acknowledgements credit the original artists/model pages and CC BY 4.0 license.

Use only the two exact user-supplied files: `my-name-is-optimus-prime.mp3` and `bumblebees-transformation-3.mp3`. The Optimus Prime and Bumblebee MP3s have been uploaded unchanged at `client/public/audio/my-name-is-optimus-prime.mp3` and `client/public/audio/bumblebees-transformation-3.mp3` respectively. Keep filenames/bytes unchanged, avoid autoplay/overlap, and handle unavailable files gracefully. Settings is a compact, lightweight CSS/SVG mechanical panel with short reversible assembly, immediate usable preferences, reduced-motion support and same-page/same-scroll restoration.

## Design

- **Design movement:** Cybertronian industrial interface translated into a high-contrast editorial site, not a generic dark theme.
- **Core principles:** cinematic but content-led; machined structures and restrained energy accents; natural/reversible scroll; accessible controls and honest fallbacks.
- **Color philosophy:** near-black void and layered steel establish depth; blue signals Optimus/CSI, yellow distinguishes Bumblebee, and red/teal remain reserved for those systems. Glow is scarce and meaningful.
- **Layout paradigm:** asymmetrical editorial bands and split compositions, framed content rails, large left-aligned type and offset cards; avoid centered repeated-card grids for major sections.
- **Signature elements:** chamfered metal frame corners; thin scanning/blueprint lines and technical readouts; segmented progress and energy illumination.
- **Interaction philosophy:** each control states its mode, responds quickly, supports keyboard/touch and leaves native navigation intact. Transformation progress follows browser scroll in both directions.
- **Animation:** restrained, skippable initialization; continuous scroll-to-progress transformation; short 500–900 ms Settings assembly/disassembly; purposeful hover/focus movement; respect reduced motion and device performance; no autoplay audio.
- **Typography:** Orbitron for hero/system/character headings, Rajdhani for navigation and technical controls, Inter for body/institutional copy. Responsive sizes follow the user’s brief: cinematic 72–104 px, page hero 52–72 px, section 36–48 px, secondary 26–32 px, body 16–18 px, labels 12–14 px.
- **Brand essence:** CSI KJSIT’s real student community presented as a cinematic technical network—precise, energetic, collaborative.
- **Brand voice:** confident system language without implying that real CSI people are Transformers. Examples: “AUTOBOT NETWORK // CSI KJSIT” and “Scroll to engage the transformation sequence.”
- **Wordmark & logo:** angular CSI monogram inside an open segmented hexagonal frame, with an energy-blue circuit notch; preserve supplied CSI/Somaiya marks in institutional contexts.
- **Signature brand color:** Optimus blue `#2588FF`.

Use the supplied foundation palette: Void `#080B10`, Armor `#111820`, Steel `#202B36`, Steel Border `#344554`, Titanium `#8E9BA8`, Secondary Text `#B2C0CC`, Signal White `#E8F0F7`, Energy Blue `#37BFFF`. Optimus: `#2588FF`, `#59C9FF`, `#12314A`, glow `rgb(55 191 255 / 22%)`. Bumblebee: `#FFD029`, `#FFEA83`, `#3C3210`, glow `rgb(255 208 41 / 20%)`. Megatron: `#D94350`, `#FF6472`, `#381820`, glow `rgb(217 67 80 / 22%)`. Cybertron: `#33E0CF`, `#7EFFF0`, `#10332F`, glow `rgb(51 224 207 / 20%)`.

## Project structure

- `client/src/App.tsx`: route mapping and application shell.
- `client/src/components/`: navigation, logo/icon family, Settings, audio, loader, cards, scroll progress and scene controls.
- `client/src/pages/`: Home, Team, Events, Gallery, Technical Saturdays, Alumni, Newsletters, Sponsors and NotFound.
- `client/src/data/`: verified source-page copy, team/event/alumni/sponsor data, links and source-image map.
- `client/src/scenes/`: Optimus hosted-animation adapter, Bumblebee video timeline, Three.js atmospheric scene and accessible/static fallbacks.
- `client/src/contexts/`: persisted display/audio preferences.
- `client/src/index.css`: tokens, mechanical styling, responsive layout, focus states and reduced motion.
- `client/public/audio/`: exact user-supplied MP3s after upload; filenames and bytes unchanged.
- `client/public/csi-assets/`: optimized copies of retrievable original CSI media.
- `client/public/manus-routes.json`: complete route manifest, including aliases.

## Constraints and unresolved assets

The public site is not an original repository; some source copy and older route details are not recoverable and must not be fabricated. The Optimus model is a hosted CC BY 4.0 viewer asset, not a downloaded GLB, and its actual transformation animation must be checked in Preview before it is presented as working. Bumblebee candidates checked so far have no animation; use a transparent rendered-sequence prototype until a licensed transform animation is found. Both user-supplied MP3s are present unchanged at their exact filenames; verify browser playback before claiming audio acceptance complete. Keep accessibility, static fallbacks and clear attribution/feature disclosures in all cases.
