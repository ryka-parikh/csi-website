# TODO

## 1. Optimus homepage intro and scroll transformation
- [x] The homepage is the flagship Optimus Prime experience, with dark metallic/circuit styling and restrained electric-blue illumination.
- [x] Reveal Optimus' face; illuminate his eyes; show CSI KJSIT identity; visually initialize the system. Display exactly `CYBERTRONIAN INTERFACE SYSTEM`, `CSI KJSIT`, and `INITIALIZING AUTOBOT NETWORK...`.
- [x] Provide a visible Skip Intro control; optional 3D assets must not delay access to the site.
- [ ] As visitors scroll normally, present a futuristic vehicle scene with headlights and camera approach, then progressively separate panels, rotate/reposition wheels, divide chassis, unfold arms/extend legs, assemble armor/shoulders/torso/head, lock joints, reveal completed Optimus with electric-blue eyes, and pull back to the character plus CSI identity.
- [ ] Map scene animation continuously to scroll progress; scrolling upward reverses smoothly. Do not hijack normal browser scroll. Do not merely crossfade a truck image and robot image. Use Three.js and GSAP ScrollTrigger when a suitable model/animation is available; otherwise clearly identify an allowed licensed-animation or rendered-sequence prototype and never imply that a fully articulated model exists.
- [x] After Optimus' full reveal, transition into the real CSI KJSIT introduction, institutional information, events, teams and page navigation; blue is the dominant accent.

## 2. Character audio and global playback behavior
- [x] Place the unmodified user-supplied `my-name-is-optimus-prime.mp3` at an appropriate public audio path and use it only for the Optimus control/optional final reveal cue.
- [x] Place the unmodified user-supplied `bumblebees-transformation-3.mp3` at an appropriate public audio path and use it only for the Bumblebee scene/control.
- [x] Never replace supplied audio with external recordings, generated voice, or placeholder audio. Never autoplay on initial site open.
- [x] Each character has an obvious dedicated control allowing start, stop and replay. Optional transformation cues may occur only after a visitor explicitly enables cinematic audio; scrolling a small amount must not restart a full recording.
- [x] Do not overlap recordings. Stop or appropriately handle playback when leaving a character scene. Provide a global mute control and handle missing files and playback failures gracefully.
- [x] Optimus control identifies idle, playing, paused and unavailable states; waveform/mechanical lights animate only during actual playback and return to idle when audio ends.
- [ ] Verify both supplied files exist, load, and are browser-playable after the user uploads them.

## 3. Bumblebee transformation and Events content
- [x] Create a separate Bumblebee transformation experience associated with Events, retaining the original Events copy and registration functionality.
- [x] Use a dark industrial vehicle opening, yellow headlight/environment lighting, and a scroll-controlled reversible transformation of wheels, chassis, doors, arms, legs, torso and head according to the actual available animation; use controlled camera movement, restrained yellow energy/particles, and a completed Bumblebee pose.
- [x] Use Bumblebee yellow with black/dark metallic surfaces; transition from the completed pose into the existing CSI Events content.
- [x] The Bumblebee audio control uses only `bumblebees-transformation-3.mp3`, can play the supplied file, and does not repeatedly restart during scroll or overlap unexpectedly when visitors leave the scene.

## 4. Mechanical Settings construction and functional preferences
- [x] Provide an angular segmented gear/settings icon with titanium, dark steel and current-page accent. Hover/focus illuminates edges, uses subtle rotation/segmented activation and shows an accessible Settings tooltip.
- [x] On activation, play a short mechanical sound only if audio is enabled; subtly dim the background; rotate/separate icon segments; unfold/rotate/lock angular panels like armour; progressively illuminate panel borders/dividers; reveal functional interface elements in sequence.
- [x] Reveal heading exactly `CYBERTRONIAN SYSTEM CONFIGURATION`, followed by working settings, then ready state exactly `SYSTEM CONFIGURATION // ONLINE`. Target about 500–900 ms without excessive blur/particles or long delay.
- [x] Reduced motion opens the panel immediately. Only present settings that work. Apply changes immediately where appropriate and persist suitable preferences without unnecessary personal data.
- [x] Functional Audio settings: master mute, SFX enable/disable, character-voice playback preference, and volume where supported.
- [x] Functional Visual settings: cinematic effects, reduced motion, particles, and optional simplified 3D experience.
- [x] Functional Interface settings: visual intensity only if implemented, animation preference, and a clear return to the default visual experience.
- [x] Closing reverses/disassembles the panel back toward its icon and restores the same page and approximately the same scroll/transformation state without reloading the site. It works on Home, Events and other sections, even when 3D is unavailable or animations are disabled.

## 5. Shared visual system, iconography and navigation
- [x] All pages share the metallic Cybertronian foundation. Foundation tokens: Void `#080B10`; Armor `#111820`; Steel `#202B36`; Steel Border `#344554`; Titanium `#8E9BA8`; Secondary Text `#B2C0CC`; Signal White `#E8F0F7`; Energy Blue `#37BFFF`.
- [x] Character colors: Optimus `#2588FF` / `#59C9FF` / `#12314A` / `rgb(55 191 255 / 22%)`; Bumblebee `#FFD029` / `#FFEA83` / `#3C3210` / `rgb(255 208 41 / 20%)`; Megatron `#D94350` / `#FF6472` / `#381820` / `rgb(217 67 80 / 22%)`; Cybertron `#33E0CF` / `#7EFFF0` / `#10332F` / `rgb(51 224 207 / 20%)`. Keep most UI dark, use accents for meaningful actions/focus/active states, and do not make all elements glow.
- [x] Use Orbitron for headings/hero/character/system text; Rajdhani for navigation/buttons/metadata/technical readouts; Inter for ordinary CSI content. Responsive sizes follow the brief: cinematic 72–104 px, page hero 52–72 px, section 36–48 px, secondary 26–32 px, body 16–18 px, interface labels 12–14 px; maintain contrast.
- [x] Provide original angular/segmented/chamfered mechanical SVG icons for Home, Events, Teams, Gallery, Technical Saturdays, Alumni, Newsletters, Sponsors, Search, Settings, Audio, Mute, Close and Scroll Progress.
- [x] Navigation includes actual existing website destinations, has metallic surface, active-page indicator and character-specific accents. Buttons have machined surfaces/angular edges/subtle depth and applicable default, hover, active, focus, disabled, loading, success and error states. No decorative controls that imply unavailable behavior.

## 6. Existing CSI content, pages, media and links
- [x] Preserve actual content, routes, real people/team details, event information, gallery images, alumni records/testimonials, newsletters, sponsor information/logos, registration links and functionality wherever present in the public reference.
- [x] Home includes the actual introduction/institutional content. Events preserves actual event information and registration links. Team includes verified members and roles. Gallery uses retrievable original photographs. Technical Saturdays preserves verified content. Alumni preserves verified records/testimonials. Newsletters preserves the actual newsletter archive/status. Sponsors preserves actual sponsor names/logos/links. About and every other discovered page receive the shared system while retaining verified information.
- [x] Do not remove or invent information. Do not use the Transformers theme to imply anything about real CSI students/faculty. Maintain existing actual destinations and social links.
- [x] If public-only reconstruction means some source content/functionality/assets cannot be retrieved, keep the limitation explicit and do not substitute fabricated CSI details.

## 7. Performance, accessibility and route coverage
- [x] Load essential CSI content before optional cinematic assets; optimize 3D/textures/rendering; lazy-load the secondary character scene; provide static/simplified fallbacks for missing WebGL/assets and shorter mobile experiences.
- [x] Settings remains usable without 3D and with all animation disabled. Respect system/user reduced motion; keyboard-operable controls have visible focus; icon-only buttons have accessible labels; text remains readable; ordinary navigation works; visitors are not trapped in pinned scenes.
- [x] Support desktop, tablet and mobile. Keep Settings state and scroll/transformation state when closing.
- [x] Keep `public/manus-routes.json` synchronized with every route, including route aliases; verify it is returned as JSON by GET.

## 8. Complete working build and honest handoff
- [ ] Application builds without critical errors. Inspect route/content wiring and diagnostics; verify settings functionality, scroll reversal, responsive/accessibility behavior and audio playback once assets are supplied.
- [x] Missing audio/3D assets never break the application. Report clearly any remaining feature that requires an external or rigged 3D asset; do not say complete when a required asset or behavior is still pending.
